#include "Speed.h"

int32_t last_speed_err;
void Speed_Loop(void)
{
	G_MotorPid.SPD_Max = 10120000; //8000*2^8;

	 int32_t speed_err = G_MotorPid.Speed_Give - G_Motor_State.Angle_speed;
//		speed_err = my_LPF(speed_err,last_speed_err);

	G_MotorPid.Speed_Inte += (G_MotorPid.KI_SPD * speed_err)>>4;//速度积分
	if(G_MotorPid.Speed_Inte > G_MotorPid.SPD_Max)//积分限制
	{
		G_MotorPid.Speed_Inte = G_MotorPid.SPD_Max;
	}
	else if(G_MotorPid.Speed_Inte < 0)
	{
	 G_MotorPid.Speed_Inte = 0;
	}
	
	if(speed_err<0)
		speed_err = 0;
	G_MotorPid.SPD_Uq = ((G_MotorPid.KP_SPD*speed_err + G_MotorPid.Speed_Inte)>>8);
	if(G_MotorPid.SPD_Uq>20000)
		G_MotorPid.SPD_Uq = 20000;
	
	last_speed_err = speed_err;
}

void Speed_Up(uint8_t *up_flag,uint8_t up_time)
{
	static uint8_t up_interval=0;
	if(*up_flag)
	{
		up_interval++;
		if(up_interval>=up_time)
			up_interval=0,G_MotorPid.Speed_Add++;
		if(G_Motor_State.DIR ^ G_Motor_State.polarity)
		{
			if(G_MotorPid.Speed_Add>=G_MotorParam.up_speed_set)//4000----3152转
				*up_flag=0;
		}
		else
		{
			if(G_MotorPid.Speed_Add>=G_MotorParam.down_speed_set)//4000----3152转
				*up_flag=0;
		}
			
	}
	
}

uint8_t Speed_Down(uint8_t down_time)
{
	static uint8_t down_interval=0;
	down_interval++;
		if(down_interval>=down_time)
			down_interval=0,G_MotorPid.Speed_Add-=4;
		if(G_MotorPid.Speed_Add<500 && AngleSin_Cos.IQAngle<500)
			return 1;
		else
			return 0;
}
