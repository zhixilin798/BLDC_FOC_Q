#ifndef __POSITION_H
#define __POSITION_H

#include "stm32f10x.h" 
#include "Function.h"


void Angle_Update(uint8_t motor_dir);
void Angle_Drag(uint8_t motor_dir,uint16_t angle_increment);
void Position_loop(uint8_t motor_dir);
#endif
