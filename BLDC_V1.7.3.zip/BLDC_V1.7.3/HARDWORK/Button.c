#include "Button.h"
uint8_t last_key_state[3]={1,1,1};

uint8_t key_get(void)
{
	uint8_t num;
	uint8_t key_state[3];
	key_state[0] = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11);
	if(key_state[0]==0 && last_key_state[0]==1)
		num=1;
	last_key_state[0] = key_state[0];
	return num;
}

void Key_Manage(uint8_t *key_num)
{
	if(*key_num )
	{
		switch(*key_num){
			case 1:
				G_Motor_State.SET_MODEL = 1;
				IR_FIRST_FLAG = 1;//对码标志位
				Buzzer_Flag = 1,Buzzer_Run_Count=3;
				break;
		}
		*key_num = 0;
	}
}
