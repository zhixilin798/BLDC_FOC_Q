#ifndef __BUTTON_H
#define __BUTTON_H

#include "gpio.h"
#include "Function.h"
#include "IR.h"
#include "Buzzer.h"
uint8_t key_get(void);
void Key_Manage(uint8_t *key_num);
#endif
