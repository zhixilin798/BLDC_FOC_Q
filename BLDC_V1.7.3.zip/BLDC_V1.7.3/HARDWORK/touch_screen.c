#include "touch_screen.h"

uint8_t Screen_Con_Flag=0,Screen_Send_Flag=0;
Screen_Param_t Scren_Para;
const Screen_Map_t Screen_Map[]={
	{0xF002,(uint16_t *)&Scren_Para.motor1_up},
	{0xF003,(uint16_t *)&Scren_Para.motor1_stop},
	{0xF001,(uint16_t *)&Scren_Para.motor1_down},
	{0xC040,(uint16_t *)&Scren_Para.motor1_up_rpm},//上升转速
	{0xC030,(uint16_t *)&Scren_Para.motor1_down_rpm},//下降转速
	{0xF801,(uint16_t *)&Scren_Para.motor1_up_degree},//开窗程度
	{0xFFF0,(uint16_t *)&Scren_Para.window_limit_enter_exit},//进入(0x5A)/退出(0x01)行程设置界面
	{0xFA31,(uint16_t *)&Scren_Para.window_up_limit_set},//上行程确认
	{0xFA32,(uint16_t *)&Scren_Para.window_down_limit_set},//下行程确认
	

};

const Screen_State_Map_t Screen_State_Map[]={
	{0xFD10,(uint8_t *)&Scren_Para.motor_pos_flag},
//	{0xFD10,(uint8_t *)&null_data},
};
	
void Screen_Con(void)
{
	if(Screen_Con_Flag)
	{
		if(*Screen_Map[0].param)//模拟FR启动
		{
			IR_FLAG = 1;
			IR_Addr = 0x21;
			IR_Com = KEY1_DOWN;
			*Screen_Map[0].param=0;
		}
		else if(*Screen_Map[1].param)//模拟FR停止
		{
			
			IR_FLAG = 1;
			IR_Addr = 0x21;
			IR_Com = KEY2_DOWN;
			*Screen_Map[1].param=0;
		}
		else if(*Screen_Map[2].param)//模拟IR启动
		{
			
			IR_FLAG = 1;
			IR_Addr = 0x21;
			IR_Com = KEY3_DOWN;
			*Screen_Map[2].param=0;
		}
		else if(*Screen_Map[3].param)//up速度
		{
			G_MotorParam.up_speed_set = 3172*(*Screen_Map[3].param)/5000;
			*Screen_Map[3].param=0;
		}
		else if(*Screen_Map[4].param)//down速度
		{
			G_MotorParam.down_speed_set = 3172*(*Screen_Map[4].param)/5000;
			*Screen_Map[4].param=0;
		}
		else if(*Screen_Map[5].param)//开窗程度
		{
			G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter + (Scren_Para.motor1_up_degree*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
			*Screen_Map[5].param=0;
		}
		else if(*Screen_Map[6].param)//进入/退出窗户行程设置界面
		{
			if(*Screen_Map[6].param == 0x5A)//进入
			{
					G_Motor_State.Limit_Set_Flag = 1;
//					G_MotorPid.Pos_Down_Setter_Flag = 0;
//					G_MotorPid.Pos_Up_Setter_Flag = 0;
					Buzzer_Flag = 1,Buzzer_Run_Count=3;
			}
			else if(*Screen_Map[6].param ==0x01)
			{
				G_Motor_State.Limit_Set_Flag = 0;
			}
			*Screen_Map[6].param=0;
		}
		else if(*Screen_Map[7].param)//上限位确认
		{
			IR_FLAG = 1;
			IR_Addr = 0x32;
			IR_Com = KEY1_UP;
			*Screen_Map[7].param=0;
		}
		else if(*Screen_Map[8].param)//下限位确认
		{
			IR_FLAG = 1;
			IR_Addr = 0x32;
			IR_Com = KEY3_UP;
			*Screen_Map[8].param=0;
		}
		
		Screen_Con_Flag=0;
	}
}
void Screen_recive_u16(void)
{
	uint16_t addr,data;
	addr = RX_data[2]<<8;
	addr |= RX_data[3];
	data = RX_data[7]<<8;
	data |= RX_data[8];
	for(uint16_t i=0;i<MAP_SIZE;i++)
	{
		if(addr == Screen_Map[i].addr)
		{
			*Screen_Map[i].param = data;
			Screen_Con_Flag=1;
		}
			
	}
	Screen_Con();
}

void Screen_Send_Data(void)
{
	uint16_t data;
	if(Screen_Send_Flag)
	{
		TX_data[0] = SCREEN_ADDR;
		TX_data[1] = 0xA2;
		TX_data[2] = RX_data[2];
		TX_data[3] = RX_data[3];
		TX_data[4] = 0;
		TX_data[5] = 0;
		TX_data[6] = 0;
		
		if(*Screen_State_Map[0].param)
		{
			data = 100-(100*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Back))/(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter);
			TX_data[7] = 0;
			TX_data[8] = data;
			*Screen_State_Map[0].param = 0;
		}
		else if(*Screen_State_Map[1].param)
		{

			*Screen_State_Map[1].param = 0;
		}
		TX_data[9] = (TX_data[0]+TX_data[1]+TX_data[2]+TX_data[3]+TX_data[4]+TX_data[5]+TX_data[6]+TX_data[7]+TX_data[8]);
		TX_EN;
		UART_Send_String((char *)&TX_data,10);
		Delay_ms(1);
		RX_EN;
		Screen_Send_Flag = 0;
	}
	
}

void Screen_send_u16(void)
{
	/*
					0			 1		   2  		 3 		  4   		|5 6 7 8|    9
			地址 		CMD		ADDR_H	ADDR_L	ERR清除		|数据区|		校验
	*/
	uint16_t addr;
	addr = RX_data[2]<<8;
	addr |= RX_data[3];
	for(uint16_t i=0;i<STATE_MAP_SIZE;i++)
	{
		if(addr == Screen_State_Map[i].addr)
		{
			 *Screen_State_Map[i].param = 1;
			Screen_Send_Flag = 1;
		}
	}
		Screen_Send_Data();
}

void UART_Receive_Con(void)
{
	if(RX_Flag==1 && RX_ms>=5)
	{
		if(RX_data[0] == SCREEN_ADDR)
		{
			switch(RX_data[1]){
				case 0xA0:
					Screen_send_u16();
					break;
				case 0x51:
					
					break;
				case 0x52:
					Screen_recive_u16();
					break;
				case 0x54:
					
					break;
				default:
					break;
			}
		}
		else if(RX_data[0] == 0x55)
		{
			
		}
			
//			GPIOB->ODR ^= GPIO_Pin_0;
			RX_Flag = 0;
			p_data = 0;
		}
}

