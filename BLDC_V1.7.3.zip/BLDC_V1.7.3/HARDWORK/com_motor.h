#include "pwm.h"
#include "uart.h"

extern char control_map[10][10];
