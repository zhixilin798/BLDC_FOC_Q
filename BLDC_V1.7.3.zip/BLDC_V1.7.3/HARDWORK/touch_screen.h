#include "uart.h"
#include "IR.h"
#include "Delay.h"
#define SCREEN_ADDR 0x01

#define MAP_SIZE (sizeof(Screen_Map)/sizeof(Screen_Map_t))
#define STATE_MAP_SIZE (sizeof(Screen_State_Map)/sizeof(Screen_State_Map_t))
	
typedef struct{
	uint16_t addr;
	uint16_t *param;
} Screen_Map_t;

typedef struct{
	uint16_t addr;
	uint8_t *param;
} Screen_State_Map_t;

typedef struct{
	uint16_t motor1_up;
	uint16_t motor1_stop;
	uint16_t motor1_down;
	uint16_t motor2_up;
	uint16_t motor2_stop;
	uint16_t motor2_down;
	uint16_t motor1_up_rpm;
	uint16_t motor1_down_rpm;
	uint16_t motor1_up_degree;
	uint16_t window_limit_enter_exit;
	uint16_t window_up_limit_set;
	uint16_t window_down_limit_set;
	uint16_t window_up_limit_delete;
	uint16_t window_down_limit_delete;
	
	/*标志位*/
	uint8_t motor_pos_flag;//电机行程
	
}	Screen_Param_t;

void UART_Receive_Con(void);

