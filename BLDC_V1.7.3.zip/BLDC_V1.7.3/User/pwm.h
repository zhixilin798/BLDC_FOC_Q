#ifndef __PWM_H
#define __PWM_H

#include "stm32f10x.h" 

void TIM1_PWM_Init(void);
void TIM3_PWM_Init(void);

void BLDC_PWM(uint16_t duty);
void Brush_Motor_UP(uint16_t duty);
void Brush_Motor_Down(uint16_t duty);
void Brush_Motor_Stop(void);
#endif
