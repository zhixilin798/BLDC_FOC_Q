#include "adc.h"
#include "stm32f10x.h"                  // Device header

uint16_t AD_Value[4];					//定义用于存放AD转换结果的全局数组

void AD_DMA_Init(void)
{
    /* 1. 开启时钟 *****************************************************/
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 |
                           RCC_APB2Periph_GPIOA, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    /* 2. ADC 时钟 12 MHz（72 MHz / 6）*********************************/
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);

    /* 3. GPIO 模拟输入 *************************************************/
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);



    /* 5. ADC 模式 ******************************************************/
    ADC_InitTypeDef ADC_InitStructure;
    ADC_InitStructure.ADC_Mode               = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode       = ENABLE;          // 扫描 3 通道
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;        
    ADC_InitStructure.ADC_ExternalTrigConv   = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign          = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel       = 3;
    ADC_Init(ADC1, &ADC_InitStructure);
	
//	/* 4. ADC 规则组通道配置（Rank1~3）*********************************/
//    ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 1, 0x07);
//    ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 2, 0x07);
//    ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 3, 0x07);
//	  ADC_ExternalTrigConvCmd(ADC1,ENABLE);
		
		// 5. 注入组配置（关键）
    ADC_InjectedSequencerLengthConfig(ADC1, 3);  // 1个注入通道
//    ADC_InjectedChannelConfig(ADC1, ADC_Channel_3, 1, 0x07); // CH0，7.5周期采样
//		ADC_InjectedChannelConfig(ADC1, ADC_Channel_4, 2, 0x06); // CH0，7.5周期采样
//		ADC_InjectedChannelConfig(ADC1, ADC_Channel_5, 3, 0x06); // CH0，7.5周期采样
		ADC_InjectedChannelConfig(ADC1, ADC_Channel_3, 1, 0x01); // CH0，7.5周期采样
		ADC_InjectedChannelConfig(ADC1, ADC_Channel_4, 2, 0x06); // CH0，7.5周期采样
		ADC_InjectedChannelConfig(ADC1, ADC_Channel_5, 3, 0x07); // CH0，7.5周期采样
		
    ADC_ExternalTrigInjectedConvConfig(ADC1, ADC_ExternalTrigInjecConv_T1_CC4); // TIM1_CH4触发
    ADC_ExternalTrigInjectedConvCmd(ADC1, ENABLE);  // 使能外部触发
    ADC_ITConfig(ADC1, ADC_IT_JEOC, ENABLE);  // 注入转换结束中断
		
		// 7. 中断优先级配置
		NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = ADC1_2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    // 8. 使能ADC并校准
    ADC_Cmd(ADC1, ENABLE);
    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));

//    /* 6. DMA1-CH1 配置 *************************************************/
//    DMA_InitTypeDef DMA_InitStructure;
//    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;
//    DMA_InitStructure.DMA_MemoryBaseAddr     = (uint32_t)AD_Value; // uint16_t AD_Value[3]
//    DMA_InitStructure.DMA_DIR                = DMA_DIR_PeripheralSRC;
//    DMA_InitStructure.DMA_BufferSize         = 3;                // 3 个半字
//    DMA_InitStructure.DMA_PeripheralInc      = DMA_PeripheralInc_Disable;
//    DMA_InitStructure.DMA_MemoryInc          = DMA_MemoryInc_Enable;
//    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
//    DMA_InitStructure.DMA_MemoryDataSize     = DMA_MemoryDataSize_HalfWord;
//    DMA_InitStructure.DMA_Mode               = DMA_Mode_Circular; // 循环
//    DMA_InitStructure.DMA_Priority           = DMA_Priority_Medium;
//    DMA_InitStructure.DMA_M2M                = DMA_M2M_Disable;
//    DMA_Init(DMA1_Channel1, &DMA_InitStructure);

//    /* 7. DMA 中断：每完成一整帧触发一次 *******************************/
//    DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE); // 传输完成中断

//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);			//配置NVIC为分组1

//    NVIC_InitStructure.NVIC_IRQChannel                   = DMA1_Channel1_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 3;
//    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);

//    /* 8. 使能 *********************************************************/
//    DMA_Cmd(DMA1_Channel1, ENABLE);
//    ADC_DMACmd(ADC1, ENABLE);
//    ADC_Cmd(ADC1, ENABLE);
	
    /* 9. 校准 *********************************************************/
//    ADC_ResetCalibration(ADC1);
//    while (ADC_GetResetCalibrationStatus(ADC1));
//    ADC_StartCalibration(ADC1);
//    while (ADC_GetCalibrationStatus(ADC1));
}


