#include "pwm.h"

void TIM1_PWM_Init(void)
{
	GPIO_InitTypeDef        gpio;
	TIM_TimeBaseInitTypeDef tim;
	TIM_OCInitTypeDef       oc;
	TIM_BDTRInitTypeDef     bdtr;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	/* 1. 开时钟 *************************************************************/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
													RCC_APB2Periph_TIM1, ENABLE);   

	/* 2. GPIO 配置 **********************************************************/
	/* PA8  -> TIM1_CH1 , PA9  -> TIM1_CH2 , PA10 -> TIM1_CH3 */
	gpio.GPIO_Pin   = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;
	gpio.GPIO_Mode  = GPIO_Mode_AF_PP;
	gpio.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &gpio);

	/* PB13 -> TIM1_CH1N, PB14 -> TIM1_CH2N, PB15 -> TIM1_CH3N */
	gpio.GPIO_Pin   = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	gpio.GPIO_Mode  = GPIO_Mode_AF_PP;
	gpio.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &gpio);

	/* 3. 时基配置 ***********************************************************/
	TIM_TimeBaseStructInit(&tim);
	tim.TIM_Prescaler         = 0;                    // 72 MHz 计数
	tim.TIM_CounterMode       = TIM_CounterMode_CenterAligned3; // 中心对齐，下计数触发DMA
	tim.TIM_Period            = 3600-1;                  // 12 kHz 频率 (72M/(3000/2)
	tim.TIM_ClockDivision     = TIM_CKD_DIV1;
	tim.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM1, &tim);

	/* 4. PWM 通道配置 *******************************************************/
	TIM_OCStructInit(&oc);
	oc.TIM_OCMode       = TIM_OCMode_PWM1;
	oc.TIM_OutputState  = TIM_OutputState_Enable;
	oc.TIM_OutputNState = TIM_OutputNState_Enable;    // 互补输出使能
	oc.TIM_Pulse        = 0;                       
	oc.TIM_OCPolarity   = TIM_OCPolarity_High;
	oc.TIM_OCNPolarity  = TIM_OCPolarity_High;
	oc.TIM_OCIdleState  = TIM_OCIdleState_Reset;
	oc.TIM_OCNIdleState = TIM_OCNIdleState_Reset;

	TIM_OC1Init(TIM1, &oc);
	TIM_OC2Init(TIM1, &oc);
	TIM_OC3Init(TIM1, &oc);

	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);
	
	//CH4作为ADC触发源：在PWM中心点触发
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 3600 / 2;  // CH4占空比50%，对齐PWM中心
    TIM_OC4Init(TIM1, &TIM_OCInitStructure);

	/* 5. 死区与高级控制 *****************************************************/
	TIM_BDTRStructInit(&bdtr);
	bdtr.TIM_OSSRState       = TIM_OSSRState_Enable;
	bdtr.TIM_OSSIState       = TIM_OSSIState_Enable;
	bdtr.TIM_LOCKLevel       = TIM_LOCKLevel_1;
	/* 死区时间 = 400 ns @72 MHz  (DTG[7:0]=0x7C)  */
	bdtr.TIM_DeadTime        = 0x08;
	bdtr.TIM_Break           = TIM_Break_Disable;
	bdtr.TIM_BreakPolarity   = TIM_BreakPolarity_Low;
	bdtr.TIM_AutomaticOutput = TIM_AutomaticOutput_Enable;
	TIM_BDTRConfig(TIM1, &bdtr);

	/* 6. 启动 ***************************************************************/
	TIM_Cmd(TIM1, ENABLE);            // 计数器使能
	TIM_CtrlPWMOutputs(TIM1, ENABLE); // 主输出使能
//	TIM_SelectOutputTrigger(TIM1, ADC_ExternalTrigConv_T1_CC1);   //跟新事件RTGO
}

void TIM3_PWM_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);			//开启TIM2的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);			//开启GPIOA的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;		//GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);							//将PA0引脚初始化为复用推挽输出	
																	//受外设控制的引脚，均需要配置为复用模式		
	
	/*配置时钟源*/
	TIM_InternalClockConfig(TIM3);		//选择TIM2为内部时钟，若不调用此函数，TIM默认也为内部时钟
	
	/*时基单元初始化*/
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;				//定义结构体变量
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;     //时钟分频，选择不分频，此参数用于配置滤波器时钟，不影响时基单元功能
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up; //计数器模式，选择向上计数
	TIM_TimeBaseInitStructure.TIM_Period = 100 - 1;					//计数周期，即ARR的值
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;				//预分频器，即PSC的值
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;            //重复计数器，高级定时器才会用到
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);             //将结构体变量交给TIM_TimeBaseInit，配置TIM2的时基单元
	
	/*输出比较初始化*/
	TIM_OCInitTypeDef TIM_OCInitStructure;							//定义结构体变量
	TIM_OCStructInit(&TIM_OCInitStructure);							//结构体初始化，若结构体没有完整赋值
																	//则最好执行此函数，给结构体所有成员都赋一个默认值
																	//避免结构体初值不确定的问题
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;				//输出比较模式，选择PWM模式1
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;		//输出极性，选择为高，若选择极性为低，则输出高低电平取反
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;	//输出使能
	TIM_OCInitStructure.TIM_Pulse = 0;								//初始的CCR值
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);						
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);						
	
	/*TIM使能*/
	TIM_Cmd(TIM3, ENABLE);			
}

void BLDC_PWM(uint16_t duty)
{
	TIM1->CCR1 = duty;
	TIM1->CCR2 = duty;
	TIM1->CCR3 = duty;
}

void Brush_Motor_UP(uint16_t duty)
{
	TIM3->CCR1 = 100;
	TIM3->CCR2 = duty;
}

void Brush_Motor_Down(uint16_t duty)
{
	TIM3->CCR1 = duty;
	TIM3->CCR2 = 100;
}

void Brush_Motor_Stop(void)
{
	TIM3->CCR1 = 0;
	TIM3->CCR2 = 0;
}
