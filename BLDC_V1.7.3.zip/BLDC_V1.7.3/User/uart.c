#include "uart.h"

uint8_t RX_Char,p_data=0,RX_Flag=0;
uint8_t RX_data[20];
uint16_t RX_ms;
uint8_t TX_data[20];

void Serial_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);	//开启USART1的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	//开启GPIOA的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);					//将PA9引脚初始化为复用推挽输出
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);					//将PA10引脚初始化为上拉输入
	
	GPIO_PinRemapConfig(GPIO_Remap_USART1, ENABLE);        //引脚映射初始化
	
	/*USART初始化*/
	USART_InitTypeDef USART_InitStructure;					//定义结构体变量
	USART_InitStructure.USART_BaudRate = 115200;				//波特率
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;	//硬件流控制，不需要
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;	//模式，发送模式和接收模式均选择
	USART_InitStructure.USART_Parity = USART_Parity_No;		//奇偶校验，不需要
	USART_InitStructure.USART_StopBits = USART_StopBits_1;	//停止位，选择1位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;		//字长，选择8位
	USART_Init(USART1, &USART_InitStructure);				//将结构体变量交给USART_Init，配置USART1
	
	/*中断输出配置*/
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);			//开启串口接收数据的中断
	
	/*NVIC中断分组*/
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);			//配置NVIC为分组2
	
	/*NVIC配置*/
	NVIC_InitTypeDef NVIC_InitStructure;					//定义结构体变量
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;		//选择配置NVIC的USART1线
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//指定NVIC线路使能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;		//指定NVIC线路的抢占优先级为1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//指定NVIC线路的响应优先级为1
	NVIC_Init(&NVIC_InitStructure);							//将结构体变量交给NVIC_Init，配置NVIC外设
	
	/*USART使能*/
	USART_Cmd(USART1, ENABLE);								//使能USART1，串口开始运行
}
void UART_Send_String(char data[],uint8_t size)
{
	for(uint8_t i=0;i<size;i++)
	{
		USART_SendData(USART1,data[i]);
		while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	//等待发送完成
	}
		
}
void UART_Send_Command(char data[10][10],uint8_t p_com,uint8_t size)
{
	for(uint8_t i=0;i<size;i++)
	{
		USART_SendData(USART1,data[p_com][i]);
		while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	//等待发送完成
	}
}


void USART1_IRQHandler(void)
{
	if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)		//判断是否是USART1的接收事件触发的中断
	{
		RX_Char = USART_ReceiveData(USART1);				//读取数据寄存器，存放在接收的数据变量
		RX_data[p_data++] = RX_Char;			
		RX_ms=0;
		RX_Flag=1;
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);			//清除USART1的RXNE标志
	}
}


//unsigned char rx1_data[256]={0};
//unsigned char rx1_n=0;
//unsigned char flag_usart1=0;//帧接收完成标志
// 
////串口1重映射配置函数
////USART1_TX,PA9----->>>PB6----TX
////USART1_RX,PA10---->>>PB7----RX
//void init_remap_usart1(u32	bound)
//{
//    GPIO_InitTypeDef Gpio_Init;
//    NVIC_InitTypeDef Nvic_Init;
//    USART_InitTypeDef Usart_Init;
//    
//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);    //打开串口1和要映射到的那个1端口和复用时钟
//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
//	
////1.需要用到外设的重映射功能时
////2.用到外部中断（EXTI）中与AFIO有关的寄存器时，它们是用来选择EXTIx外部中断的输入脚之用。	
//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);	
//    
//    Gpio_Init.GPIO_Pin = GPIO_Pin_6;        //把PB6设置为USART1--TX，
//    Gpio_Init.GPIO_Mode = GPIO_Mode_AF_PP;    
//    Gpio_Init.GPIO_Speed = GPIO_Speed_50MHz; 
//    GPIO_Init(GPIOB, &Gpio_Init);
//    
//    Gpio_Init.GPIO_Pin = GPIO_Pin_7;    //把PB7设置为USART1--RX，
//    Gpio_Init.GPIO_Mode = GPIO_Mode_IN_FLOATING;
//    GPIO_Init(GPIOB, &Gpio_Init);
//    GPIO_PinRemapConfig(GPIO_Remap_USART1, ENABLE);        //引脚映射初始化
//     
//    Usart_Init.USART_BaudRate = bound;
//    Usart_Init.USART_WordLength = USART_WordLength_9b;	
//    Usart_Init.USART_StopBits = USART_StopBits_1;
//    Usart_Init.USART_Parity = USART_Parity_Even;		//偶校验
//    Usart_Init.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	
//    Usart_Init.USART_HardwareFlowControl = USART_HardwareFlowControl_None;	
//    USART_Init(USART1, &Usart_Init);
//    USART_Cmd(USART1, ENABLE);
//    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);		//设置接收字节中断
//	USART_ITConfig(USART1,USART_IT_IDLE, ENABLE);		//设置接收帧中断（串口空闲中断）
//	
////   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
//    Nvic_Init.NVIC_IRQChannel = USART1_IRQn;        
//    Nvic_Init.NVIC_IRQChannelCmd = ENABLE;
//    Nvic_Init.NVIC_IRQChannelPreemptionPriority = 7;
//    Nvic_Init.NVIC_IRQChannelSubPriority = 0;
//    NVIC_Init(&Nvic_Init);	
//}
// 
// 
//void send1_buff(u8 *p, u8 len)
//{	
//	USART_ClearFlag( USART1, USART_FLAG_TC );	//防止第一个字节丢失
//	while(len--)
//	{	
//	USART_SendData(USART1, *(p++));         //向串口1发送数据
//	while(USART_GetFlagStatus(USART1,USART_FLAG_TC)!=SET);//等待发送结束
//	}	
//}
// 
// 
////UART1 接收中断
//void USART1_IRQHandler(void)
//{
//	u8	clear;	
//	clear=clear;		//消除KEIL编译报警
//	if(USART_GetITStatus(USART1,USART_IT_RXNE) == SET)	//USART_IT_RXNE=接收中断标志位，读操作会清零
//	{	
//	rx1_data[rx1_n] = USART_ReceiveData(USART1);
//	rx1_n++;
//	}
//	else if(USART_GetITStatus(USART1, USART_IT_IDLE) != RESET)	//空闲帧中断
//	{							
//	clear =USART1->DR;  //先读取接收缓存中数据,目的是清空闲中断标志位 （USART_IT_IDLE=0）
//	clear = USART1->SR;	
//	flag_usart1=1;				//一帧数据接收结束标志
//	}	
// 
//}
