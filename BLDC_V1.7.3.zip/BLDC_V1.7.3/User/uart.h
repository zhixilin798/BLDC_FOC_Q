#ifndef __UART_H
#define __UART_H

#include "stm32f10x.h" 

#define RX_EN GPIO_ResetBits(GPIOB,GPIO_Pin_12)
#define TX_EN GPIO_SetBits(GPIOB,GPIO_Pin_12)

void Serial_Init(void);
void UART_Send_String(char data[],uint8_t size);
void UART_Send_Command(char data[10][10],uint8_t p_com,uint8_t size);

extern uint8_t RX_data[20],TX_data[20];
extern uint8_t RX_Flag,p_data;
extern uint16_t RX_ms;
#endif
