#include "stm32f10x.h"                   // Device header
#include "Delay.h"
#include "uart.h"
#include "gpio.h"
#include "pwm.h"
#include "adc.h"
#include "tim_hall.h"
#include "stdio.h"
#include "string.h"
#include "Position.h"
#include "IR.h"
#include "Speed.h"
#include "Current.h"
#include "flash.h"
#include "com_motor.h"
#include "Button.h"
#include "buzzer.h"
#include "touch_screen.h"

uint8_t adc_flag=1;
char buff[30];
uint8_t KEY_NUM;
uint8_t button1,button2;
int main()
{
	G_MotorParam.overCurrent = 2400;//2310---2.5A电流
	GPIO_OUT_Init();
	GPIO_IN_Init();
	TIM1_PWM_Init();
	AD_DMA_Init();
	Serial_Init();
	HALL_Init();
	TIM4_Init();
	TIM3_Init();
//	TIM3_PWM_Init();
	IR_Init();
	Power_Failure_Detection_Init();
	Store_Init();
	
	
	TIM1->CCR1 = 400;
	TIM1->CCR2 = 400;
	TIM1->CCR3 = 400;
	Delay_ms(100);
	if(TOGGLE_SWITCH_1==0)//拨码选择电机极性
		G_Motor_State.polarity = 0;
	else
		G_Motor_State.polarity = 1;
//	Brush_Motor_UP(0);
//	Brush_Motor_Down(0);
	BRAKE_OFF;
	G_Motor_State.DIR=0;
//GPIOB->ODR ^= GPIO_Pin_0;

	TIM3->CCR1 = 0;
	TIM3->CCR2 = 100;
	G_MotorPid.KP_POS = 90;
	G_MotorPid.KP_SPD = 600;
	G_MotorPid.KI_SPD = 10;
//	G_MotorPid.KP_CUR = 2500;
//	G_MotorPid.KI_CUR = 15;
	G_MotorPid.Speed_Give = 3000;
	G_MotorPid.Speed_Add = 0;
//	G_MotorPid.Pos_Down_Setter = -2000;
//	G_MotorPid.Pos_Up_Setter = 2000;
	BRAKE_ON;
	button1 = GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8);
	button2 = GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9);
//	Buzzer_ON();
//	Delay_ms(500);
//	Buzzer_OFF();
	
	while (1)
	{
		UART_Receive_Con();
		Buzzer_Running(&Buzzer_Flag,Buzzer_Run_Count);
		KEY_NUM = key_get();
		Key_Manage(&KEY_NUM);
		IR_Con(&IR_FLAG);
//		GPIOB->ODR ^= GPIO_Pin_0;
		
		
//		sprintf(buff,"%d,%d,%d,%d,%d,%d\n",HALL_STATE,G_Motor_State.Angle_speed,G_MotorPid.Speed_Give,AD_Value[0],AD_Value[1],AD_Value[2]);
//		sprintf(buff,"%d,%d,%d,%d,%d\n",AngleSin_Cos.IQAngle,
//																		G_MotorPid.CUR_Give,
//																		HALL_STATE,
//																		G_MotorPid.Speed_Give,
//																		G_Motor_State.Angle_speed);
//		UART_Send_String(buff,strlen(buff));

	}
}

uint16_t num=300;
int32_t temp=16384*3;


// ADC注入转换完成中断
void ADC1_2_IRQHandler(void)
{
//		GPIOB->ODR ^= GPIO_Pin_0;
    if(ADC_GetITStatus(ADC1, ADC_IT_JEOC) != RESET)
    {
			ADC_Sample(adc_flag);
			if(G_Motor_State.RUN_STATE==1)//强拖
			{
				if(direction_turn_angle_compensation(G_Motor_State.DIR))//方向翻转
				{
					G_Motor_State.Angle_speed = 0;
					G_MotorPid.Speed_Inte = 1120000;
					if(G_Motor_State.DIR)
						AngleSin_Cos.IQAngle += temp;
					else
						AngleSin_Cos.IQAngle -= temp;
				}

				Angle_Drag(G_Motor_State.DIR,20);
				IQSin_Cos_Cale((p_IQSin_Cos)&AngleSin_Cos); //角度转换
				IparkU.Sine=AngleSin_Cos.IQSin;//sin值
				IparkU.Cosine=AngleSin_Cos.IQCos;//cos值
				
				motor_svpwm(4500,4500,G_Motor_State.DIR);
				num--;
				if(num<=2)
					G_Motor_State.RUN_STATE=2,num=300,G_Motor_State.Speed_Up_Flag=1;
			}
			else if(G_Motor_State.RUN_STATE==2)//闭环
			{
				/*角度获取*/
				Angle_Update(G_Motor_State.DIR);
				IQSin_Cos_Cale((p_IQSin_Cos)&AngleSin_Cos); //角度转换
				IparkU.Sine=AngleSin_Cos.IQSin;//sin值
				IparkU.Cosine=AngleSin_Cos.IQCos;//cos值

				/*闭环控制*/
				Position_loop(G_Motor_State.DIR);
				Speed_Up(&G_Motor_State.Speed_Up_Flag,3);
				Speed_Loop();	
				if(G_Motor_State.DIR)
					motor_svpwm(G_MotorPid.SPD_Uq,G_MotorPid.Speed_Give*1,G_Motor_State.DIR);//负载越大，系数越大2/1.8
				else
					motor_svpwm(G_MotorPid.SPD_Uq,G_MotorPid.Speed_Give*1,G_Motor_State.DIR);
//				motor_svpwm(G_MotorPid.SPD_Uq,0,G_Motor_State.DIR);//MAX-30000 12000-7000
			}
			else if(G_Motor_State.RUN_STATE==3)//减速---停
			{
				Angle_Update(G_Motor_State.DIR);
				IQSin_Cos_Cale((p_IQSin_Cos)&AngleSin_Cos); //角度转换
				IparkU.Sine=AngleSin_Cos.IQSin;//sin值
				IparkU.Cosine=AngleSin_Cos.IQCos;//cos值
				
				Position_loop(G_Motor_State.DIR);
				Speed_Loop();	
				motor_svpwm(G_MotorPid.SPD_Uq,G_MotorPid.Speed_Give,G_Motor_State.DIR);
				if(Speed_Down(3)==1)//减速---减速完成SET
				{
					motor_svpwm(0,0,G_Motor_State.DIR);
					G_Motor_State.RUN_STATE=0;
					G_MotorPid.Speed_Add=0;
				}
			}
			else if(G_Motor_State.RUN_STATE==4)//设置模式下停
			{
				motor_svpwm(0,0,G_Motor_State.DIR);
				G_Motor_State.RUN_STATE = 0;
			}
		
			if(my_fmax(my_abs(AD_Value[0]),my_abs(AD_Value[1])) > G_MotorParam.overCurrent)//过流检测
			{
				G_MotorParam.overCurrent_Count++;
				if(G_MotorParam.overCurrent_Count >= 100)
				{
					motor_svpwm(0,0,G_Motor_State.DIR);
					G_Motor_State.RUN_STATE=0;
//					TIM_Cmd(TIM3,DISABLE);		
					G_MotorParam.overCurrent_flag = 1;
					G_MotorPid.Speed_Add = 0;					
				}
			}
			else
				G_MotorParam.overCurrent_Count = 0;
				
			
        ADC_ClearITPendingBit(ADC1, ADC_IT_JEOC);
    }
//		GPIOB->ODR ^= GPIO_Pin_0;
}

/*掉电检测*/
void EXTI1_IRQHandler(void)
{
	if (EXTI_GetITStatus(EXTI_Line1) == SET)		//判断是否是外部中断14号线触发的中断
	{
		Store_Data[0] = G_MotorPid.Pos_Back>>16;//当前位置
		Store_Data[1] = G_MotorPid.Pos_Back;
		Store_Data[2] = G_MotorPid.Pos_Up_Setter>>16;//上限设置值
		Store_Data[3] = G_MotorPid.Pos_Up_Setter;
		Store_Data[4] = G_MotorPid.Pos_Down_Setter>>16;//下限设置值
		Store_Data[5] = G_MotorPid.Pos_Down_Setter;
		Store_Data[6] = G_Motor_State.Pos_Up_Arrive_Flag;//到达上限位标志位
		Store_Data[7] = G_Motor_State.Pos_Down_Arrive_Flag;//到达下限位标志位
		Store_Data[15] = G_MotorPid.Pos_Up_Setter_Flag;//上限设置标志位
		Store_Data[16] = G_MotorPid.Pos_Down_Setter_Flag;//下限设置标志位
		
	  Store_Data[11] = G_MotorParam.up_speed_set;//速度
		Store_Data[12] = G_MotorParam.down_speed_set;//速度
		Store_Data[13] = G_MotorPid.Pos_Up_Set_Setter>>16;//开窗行程
		Store_Data[14] = G_MotorPid.Pos_Up_Set_Setter;//开窗行程
		
		Store_Data[8] = eq1_check[0];
		Store_Data[9] = eq1_check[1];
		Store_Data[10] = eq1_check[2];
		
		
		Store_Save();
		EXTI_ClearITPendingBit(EXTI_Line1);		//清除外部中断14号线的中断标志位
											
	}
}
/*1ms定时*/
void TIM3_IRQHandler(void)
{
	static uint16_t tim3_1ms;
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
	{
		if(G_Motor_State.SET_MODEL || G_Motor_State.Limit_Set_Flag)
		{
			tim3_1ms++;
			if(tim3_1ms>=150)
			GPIOB->ODR ^= GPIO_Pin_0,tim3_1ms=0;
		}
		if(G_Motor_State.Limit_Set_Flag==1 || G_MotorPid.Pos_Up_Setter_Flag==0 || G_MotorPid.Pos_Down_Setter_Flag==0)
		{
			Limit_Set_ms++;
			if(Limit_Set_ms>=280)//按键松开
			{
				if(G_Motor_State.RUN_STATE==2)
					G_Motor_State.RUN_STATE = 3;
				Limit_Set_ms=0;
			}
				
		}
		RX_ms++;
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
		
	}
}
