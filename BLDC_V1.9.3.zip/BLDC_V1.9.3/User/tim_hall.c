#include "tim_hall.h"

//const uint16_t Angle_revise[8]={0,44900,1750,58000,23100,36500,14500,0};//100nf
const uint16_t Angleup_revise[8]={0,43000+3000,450+3000,54000+3000,21800+3000,33000+3000,11200+3000,0};//1nf
const uint16_t Angledown_revise[8]={0,64700-3000,21400-3000,10400-3000,43100-3000,53950-3000,32250-3000,0};//1nf
uint8_t HALL_STATE=1,HALL_FLAG=1,HALL_STEP[7]={0,3,1,2,5,4,6,};
uint32_t HALL_TIM;
uint16_t stall_count=0;
uint16_t last_tim;
uint32_t hall_time=0;
void TIM4_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	TIM_InternalClockConfig(TIM4);
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	
	// 配置定时器基本参数
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_Period = 65535;
	TIM_TimeBaseStructure.TIM_Prescaler = 72-1;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
	
//	TIM_ClearFlag(TIM4, TIM_FLAG_Update);	
//	TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);					//开启TIM2的更新中断
	/*NVIC中断分组*/
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);				//配置NVIC为分组2
//																//即抢占优先级范围：0~3，响应优先级范围：0~3
//																//此分组配置在整个工程中仅需调用一次
//																//若有多个中断，可以把此代码放在main函数内，while循环之前
//																//若调用多次配置分组的代码，则后执行的配置会覆盖先执行的配置
//	/*NVIC配置*/
//	NVIC_InitTypeDef NVIC_InitStructure;						//定义结构体变量
//	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;				//选择配置NVIC的TIM2线
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				//指定NVIC线路使能
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;	//指定NVIC线路的抢占优先级为2
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;			//指定NVIC线路的响应优先级为1
//	NVIC_Init(&NVIC_InitStructure);								//将结构体变量交给NVIC_Init，配置NVIC外设
	
	TIM_Cmd(TIM4, ENABLE);
}

void TIM3_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	TIM_InternalClockConfig(TIM3);
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	
	// 配置定时器基本参数
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_Period = 1000-1;
	TIM_TimeBaseStructure.TIM_Prescaler = 72-1;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	
	TIM_ClearFlag(TIM3, TIM_FLAG_Update);	
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);					//开启TIM3的更新中断
	/*NVIC中断分组*/
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);				//配置NVIC为分组2
																//即抢占优先级范围：0~3，响应优先级范围：0~3
																//此分组配置在整个工程中仅需调用一次
																//若有多个中断，可以把此代码放在main函数内，while循环之前
																//若调用多次配置分组的代码，则后执行的配置会覆盖先执行的配置
	/*NVIC配置*/
	NVIC_InitTypeDef NVIC_InitStructure;						//定义结构体变量
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;				//选择配置NVIC的TIM2线
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				//指定NVIC线路使能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;	//指定NVIC线路的抢占优先级为2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;			//指定NVIC线路的响应优先级为1
	NVIC_Init(&NVIC_InitStructure);								//将结构体变量交给NVIC_Init，配置NVIC外设
	
	TIM_Cmd(TIM3, ENABLE);
}

void HALL_Init(void)
{
 
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_ICInitTypeDef TIM_ICInitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
//	TIM_OCInitTypeDef TIM_OCInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	// 使能GPIO时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	
	// 配置GPIO引脚为输入模式
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	 
	// 使能定时器时钟
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	// 配置定时器基本参数
	TIM_TimeBaseStructure.TIM_Period = 65535;
	TIM_TimeBaseStructure.TIM_Prescaler = 72-1;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
 
	// 配置输入捕获模式
	 
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;	 
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;	 
	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;	 
	TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;	 
	TIM_ICInitStructure.TIM_ICFilter = 0x0F;	 
	TIM_ICInit(TIM2, &TIM_ICInitStructure); 
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_2; 
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;	 
	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;	 
	TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;	 
	TIM_ICInitStructure.TIM_ICFilter = 0x0F;	 
	TIM_ICInit(TIM2, &TIM_ICInitStructure);	 
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_3;	 
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;	 
	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI; 
	TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;	 
	TIM_ICInitStructure.TIM_ICFilter = 0x0F;	 
	TIM_ICInit(TIM2, &TIM_ICInitStructure);

	// 使能定时器
	
 /*Hall Sensor 模式：三输入异或，TI1F_ED 触发 */
	TIM_SelectHallSensor(TIM2, ENABLE);          /* 使能 Hall Sensor 接口 */
	TIM_SelectInputTrigger(TIM2, TIM_TS_TI1F_ED);/* 触发源：TI1F_ED */
	TIM_SelectSlaveMode(TIM2, TIM_SlaveMode_Reset);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);			//配置NVIC为分组1
	NVIC_InitStructure.NVIC_IRQChannel                   = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	TIM_ITConfig(TIM2, TIM_IT_Trigger, ENABLE);
	TIM_Cmd(TIM2, ENABLE);
}
 




uint32_t stepup_hall_value[7] = {850000*16,1118571*16,1199357*16,1097857*16,1118571*16,1109285*16,1180000*16};
uint32_t stepdown_hall_value[7] = {850000*16,1150000*16,1080000*16,1040000*16,1079285*16,1100000*16,1078571*16};
uint8_t LAST_UP_HALL_STATE_MAP[7] = {0,5,3,1,6,4,2};
uint8_t LAST_DOWN_HALL_STATE_MAP[7] = {0,3,6,2,5,1,4};

uint16_t halltim[7][21];
uint16_t p_hall[7];
uint8_t LAST_HALL_STATE;
void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Trigger) != RESET)
	{
		uint8_t h1 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0);//a
		uint8_t h2 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1);//b
		uint8_t h3 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2);//c
		HALL_STATE = (h3 << 2) | (h2 << 1) | h1;    /* 换相函数 */
		hall_time = 0;
		if(G_Motor_State.DIR)
		{
			AngleSin_Cos.IQAngle = Angleup_revise[HALL_STATE];//校正角度
			HALL_TIM = my_LPF(TIM2->CCR1,last_tim);//低通滤波
			last_tim = HALL_TIM;
//			HALL_TIM = TIM2->CCR1;G_Motor_State.Angle_speed = stepup_hall_value[HALL_STATE]/HALL_TIM;//角速度计算
			if(LAST_UP_HALL_STATE_MAP[HALL_STATE] == LAST_HALL_STATE)
			{	
				G_Motor_State.Angle_speed = stepup_hall_value[HALL_STATE]/HALL_TIM;//角速度计算
				G_MotorPid.Pos_Back++;
			}
			else
			{
				G_Motor_State.Angle_speed = -(stepup_hall_value[HALL_STATE]/HALL_TIM);//角速度计算
				G_MotorPid.Pos_Back--;
			}
			LAST_HALL_STATE = HALL_STATE;

		}
		else
		{
			AngleSin_Cos.IQAngle = Angledown_revise[HALL_STATE];
			HALL_TIM = my_LPF(TIM2->CCR1,last_tim);//低通滤波
			last_tim = HALL_TIM;
//			HALL_TIM = TIM2->CCR1;
			G_Motor_State.Angle_speed = stepdown_hall_value[HALL_STATE]/HALL_TIM;
			if(LAST_DOWN_HALL_STATE_MAP[HALL_STATE] == LAST_HALL_STATE)
			{
				G_Motor_State.Angle_speed = stepup_hall_value[HALL_STATE]/HALL_TIM;//角速度计算
				G_MotorPid.Pos_Back--;
			}
			else
			{
				G_Motor_State.Angle_speed = stepup_hall_value[HALL_STATE]/HALL_TIM;//角速度计算
				G_MotorPid.Pos_Back++;
			}
				
			LAST_HALL_STATE = HALL_STATE;
		}
			
//		

		/*测试*/
//		halltim[HALL_STATE][p_hall[HALL_STATE]++] = AngleSin_Cos.IQAngle;
//		for(uint8_t i=0;i<7;i++)
//		{
//			if(p_hall[i]>=20)
//				p_hall[i]=0;
//		}

//		if(HALL_STATE==6)
//		{

//			HALL_TIM = my_LPF(TIM2->CCR1,last_tim);
//			last_tim = HALL_TIM;
//		}
		TIM_ClearITPendingBit(TIM2, TIM_IT_Trigger);
	}
}

