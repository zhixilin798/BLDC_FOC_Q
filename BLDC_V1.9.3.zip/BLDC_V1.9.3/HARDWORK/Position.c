#include "Position.h"

void Angle_Update(uint8_t motor_dir)
{
	if(motor_dir)
	{
		AngleSin_Cos.IQAngle+=G_Motor_State.Angle_speed>>4;
		if(AngleSin_Cos.IQAngle>=65535)
		{
			AngleSin_Cos.IQAngle-=65535;
		}
	}
	else
	{
		AngleSin_Cos.IQAngle-=G_Motor_State.Angle_speed>>4;
		if(AngleSin_Cos.IQAngle<0)
		{
			AngleSin_Cos.IQAngle+=65535;
		}
	}
}

void Angle_Drag(uint8_t motor_dir,uint16_t angle_increment)
{
	if(motor_dir)
	{
		AngleSin_Cos.IQAngle+=angle_increment;
		if(AngleSin_Cos.IQAngle>=65535)
		{
			AngleSin_Cos.IQAngle-=65535;
		}
	}
	else
	{
		AngleSin_Cos.IQAngle-=angle_increment;
		if(AngleSin_Cos.IQAngle<0)
		{
			AngleSin_Cos.IQAngle+=65535;
		}
	}
	
}

void Position_loop(uint8_t motor_dir)
{
	int32_t pos_err,pos_s;
	if(G_MotorPid.Pos_Back <= G_MotorPid.Pos_Up_Set_Setter && G_Motor_State.polarity)//在开窗程度设置范围内
	{
			if(motor_dir)
				pos_err = G_MotorPid.Pos_Up_Set_Setter - G_MotorPid.Pos_Back;
			else
				pos_err = G_MotorPid.Pos_Back - G_MotorPid.Pos_Down_Setter;
	}
	else if(G_MotorPid.Pos_Back >= G_MotorPid.Pos_Up_Set_Setter && G_Motor_State.polarity==0)
	{
		if(motor_dir)
				pos_err = G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Back;
			else
				pos_err = G_MotorPid.Pos_Back - G_MotorPid.Pos_Up_Set_Setter;
	}
	else
	{
		if(motor_dir)
			pos_err = G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Back;
		else
			pos_err = G_MotorPid.Pos_Back - G_MotorPid.Pos_Down_Setter;
	}
	
	pos_s = G_MotorPid.KP_POS * pos_err;

	if(G_Motor_State.Limit_Set_Flag==1 || G_MotorPid.Pos_Up_Setter_Flag==0 || G_MotorPid.Pos_Down_Setter_Flag==0)//点动状态下
	{
		G_MotorPid.Speed_Give=1800 + G_MotorPid.Speed_Add;
	}
	else
	{
		if(pos_s>=0)//通过G_MotorPid.Speed_Add实现加减速控制
		{
			if(G_Motor_State.DIR)
				G_MotorPid.Speed_Give=1000 + G_MotorPid.Speed_Add;
			else
				G_MotorPid.Speed_Give=1000 + G_MotorPid.Speed_Add;
		}
		if(pos_s<9000)
		{
			G_Motor_State.RUN_STATE=3;//直接进入减速
			if(G_Motor_State.DIR)//到达上限位
				G_Motor_State.Pos_Up_Arrive_Flag = 1;
			else
				G_Motor_State.Pos_Down_Arrive_Flag = 1;
		}
			
	}
	
}
