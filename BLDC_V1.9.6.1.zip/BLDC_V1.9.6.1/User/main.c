#include "stm32f10x.h"                   // Device header
#include "Delay.h"
#include "uart.h"
#include "gpio.h"
#include "pwm.h"
#include "adc.h"
#include "tim_hall.h"
#include "stdio.h"
#include "string.h"
#include "Position.h"
#include "IR.h"
#include "Speed.h"
#include "Current.h"
#include "flash.h"
#include "com_motor.h"
#include "Button.h"
#include "buzzer.h"
#include "touch_screen.h"

uint8_t adc_flag=1;
char buff[30];
uint8_t KEY_NUM;
uint8_t button1,button2;
uint8_t testflag=0;
uint16_t currentover_count;
uint8_t currentover_flag=0,currentover_num=0;
int main()
{
	static uint8_t RUN_COUNT=0;
//	RCC_Configuration();
	SysTick_Config(72000);
	G_MotorParam.overCurrent = 2450;//2450---2.5A电流
	GPIO_OUT_Init();
	GPIO_IN_Init();
	TIM1_PWM_Init();
	AD_DMA_Init();
	Serial_Init(115200);
	HALL_Init();
	TIM4_Init();
	TIM3_PWM_Init();
	IR_Init();
	Power_Failure_Detection_Init();
	Store_Init();

	my_delay_ms(500);
	G_Motor_State.DIR=0;
	G_MotorPid.KP_POS = 90;
	G_MotorPid.KP_SPD = 600;
	G_MotorPid.KI_SPD = 10;
//	G_MotorPid.KP_CUR = 2500;
//	G_MotorPid.KI_CUR = 15;
	G_MotorPid.Speed_Give = 3000;
	G_MotorPid.Speed_Add = 0;
	button1 = GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8);
	button2 = GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9);
	BRAKE_OFF;
//	BRAKE_ON;
	Screen_Motor1_Stop();
	TIM1->CCR1 = 1600;
	TIM1->CCR2 = 1600;
	TIM1->CCR3 = 1600;
	Buzzer_ON();
	my_delay_ms(500);
	Buzzer_OFF();
	
	KEY_NUM = 1;
	
	if(G_Motor_State.DIR)
		G_MotorPid.Speed_Inte = 0;
	else
		G_MotorPid.Speed_Inte = 3200000;
	G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_win;//开窗程度
//	TX_EN;
	
	
	while (1)
	{
		RUN_COUNT++;
		RUN_COUNT%=5;
		UART_Receive_Con();
		Buzzer_Running(&Buzzer_Flag,Buzzer_Run_Count);
		KEY_NUM = key_get();
		Key_Manage(&KEY_NUM);
		IR_Con(&IR_FLAG);
		
		if(RUN_COUNT==0)
			SYS_STATE_MONITOR();
		
//		sprintf(buff,"%d,%d,%d,%d,%d\n",G_MotorPid.SPD_Uq,G_Motor_State.Angle_speed,G_MotorPid.Speed_Give,AD_Value[0],AD_Value[1]);
////		sprintf(buff,"%d,%d,%d,%d,%d\n",PLL_Param.PLL_Angle,AngleSin_Cos.IQAngle,G_MotorPid.Speed_Give,AD_Value[0],AD_Value[1]);
////		sprintf(buff,"%d,%d,%d,%d,%d\n",AngleSin_Cos.IQAngle,
////																		G_MotorPid.CUR_Give,
////																		HALL_STATE,
////																		G_MotorPid.Speed_Give,
////																		G_Motor_State.Angle_speed);
//		UART_Send_String(buff,strlen(buff));

	}
}

uint16_t num=30;
int32_t temp=16384*3;

uint32_t kp1=500,ki1=180,kp2=800,ki2=150,kd=0;
// ADC注入转换完成中断
uint32_t last_uq;
void ADC1_2_IRQHandler(void)
{
//		GPIOB->ODR ^= GPIO_Pin_0;
    if(ADC_GetITStatus(ADC1, ADC_IT_JEOC) != RESET)
    {
			ADC_ClearITPendingBit(ADC1, ADC_IT_JEOC);
			SpeedPll();
			if(G_Motor_State.DIR)//下
			{
				G_MotorPid.KP_SPD = kp1;
				G_MotorPid.KI_SPD = ki1;
				G_MotorPid.KD_SPD = kd;
			}
			else
			{
				G_MotorPid.KP_SPD = kp2;
				G_MotorPid.KI_SPD = ki2;
				
			}
			ADC_Sample(adc_flag);
			if(G_Motor_State.RUN_STATE==1)//强拖
			{
				if(direction_turn_angle_compensation(G_Motor_State.DIR))//方向翻转
				{
					G_Motor_State.Angle_speed = 0;
					if(G_Motor_State.DIR ^ G_Motor_State.polarity)
					{
						G_MotorPid.Speed_Inte = 3200000;
						AngleSin_Cos.IQAngle -= temp;
					}	
					else
					{
						G_MotorPid.Speed_Inte = 0;
						AngleSin_Cos.IQAngle += temp;
						
					}
						
				}
//				if(G_Motor_State.DIR)
					G_Motor_State.RUN_STATE=2,num=30,G_Motor_State.Speed_Up_Flag=1;
				Angle_Drag(G_Motor_State.DIR,20);
				IQSin_Cos_Cale((p_IQSin_Cos)&AngleSin_Cos); //角度转换
				IparkU.Sine=AngleSin_Cos.IQSin;//sin值
				IparkU.Cosine=AngleSin_Cos.IQCos;//cos值
				
				motor_svpwm(18000,0,G_Motor_State.DIR);
				num--;
				if(num<=2)
					G_Motor_State.RUN_STATE=2,num=30,G_Motor_State.Speed_Up_Flag=1;
			}
			else if(G_Motor_State.RUN_STATE==2)//闭环
			{
				/*角度获取*/
				Angle_Update(G_Motor_State.DIR);
				IQSin_Cos_Cale((p_IQSin_Cos)&AngleSin_Cos); //角度转换
				IparkU.Sine=AngleSin_Cos.IQSin;//sin值
				IparkU.Cosine=AngleSin_Cos.IQCos;//cos值

				/*闭环控制*/
				Position_loop(G_Motor_State.DIR);
				Speed_Up(&G_Motor_State.Speed_Up_Flag,3);
				Speed_Loop();	
//				my_LPF(G_MotorPid.SPD_Uq,last_uq);
				last_uq = G_MotorPid.SPD_Uq;
				if(G_Motor_State.DIR ^ G_Motor_State.polarity)//11-00    
					motor_svpwm(G_MotorPid.SPD_Uq,2500,G_Motor_State.DIR);//负载越大，系数越大2/1.8
				else
					motor_svpwm(G_MotorPid.SPD_Uq,G_MotorPid.Speed_Give*80/100,G_Motor_State.DIR);
//				motor_svpwm(G_MotorPid.SPD_Uq,0,G_Motor_State.DIR);//MAX-30000 12000-7000
			}
			else if(G_Motor_State.RUN_STATE==3)//减速---停
			{
				Angle_Update(G_Motor_State.DIR);
				IQSin_Cos_Cale((p_IQSin_Cos)&AngleSin_Cos); //角度转换
				IparkU.Sine=AngleSin_Cos.IQSin;//sin值
				IparkU.Cosine=AngleSin_Cos.IQCos;//cos值
				
				Position_loop(G_Motor_State.DIR);
				Speed_Loop();	
				motor_svpwm(G_MotorPid.SPD_Uq,G_MotorPid.Speed_Give,G_Motor_State.DIR);
				if(Speed_Down(3)==1)//减速---减速完成SET
				{
					G_Motor_State.Stop_flag=1;
					G_Motor_State.Fast_Run_flag=0;
					KEY1_UP_COUNT=0;
					if(TURN_FLAG)
					{
						TURN_FLAG = 0;
						if(G_Motor_State.DIR)//1---1
						{
							G_MotorPid.Speed_Inte = 4000000;
							G_Motor_State.DIR = 0;
							BRAKE_ON;
							G_Motor_State.RUN_STATE = 1;
						}
						else
						{
							G_MotorPid.Speed_Inte = 0;
							G_Motor_State.DIR = 1;
							BRAKE_ON;
							G_Motor_State.RUN_STATE = 1;
							
						}
						return;
					}
//					motor_svpwm(0,0,G_Motor_State.DIR);
					G_Motor_State.RUN_STATE=0;
					G_MotorPid.Speed_Add=0;
					if(G_Motor_State.DIR)
						G_MotorPid.Speed_Inte = 0;
					else
						G_MotorPid.Speed_Inte = 3700000;
					G_Motor_State.STOP_STATE_FLAG = 1;
					G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_win;//恢复正常行程
					if(G_Motor_State.Little_Open_Start == 1)
					{
						G_Motor_State.Pos_Up_Arrive_Flag = 0;
						G_Motor_State.Pos_Down_Arrive_Flag = 0;
						G_Motor_State.Little_Open_Start = 0;
					}
				}
			}

			if(G_Motor_State.RUN_STATE && hall_time>=100)//堵转保护
			{
				G_Motor_State.Angle_speed = 0;
				if(G_Motor_State.DIR)
					AngleSin_Cos.IQAngle += 100;
				else
					AngleSin_Cos.IQAngle -= 100;
			}
//			if(my_fmax(my_abs(AD_Value[0]),my_abs(AD_Value[1])) > G_MotorParam.overCurrent)//过流检测
//			{
//				G_MotorParam.overCurrent_Count++;
//				if(G_MotorParam.overCurrent_Count >= 100)
//				{
//					motor_svpwm(0,0,G_Motor_State.DIR);
//					G_Motor_State.RUN_STATE=0;
////					TIM_Cmd(TIM3,DISABLE);		
//					G_MotorParam.overCurrent_flag = 1;
//					G_MotorPid.Speed_Add = 0;					
//				}
//			}
//			else
//				G_MotorParam.overCurrent_Count = 0;
				if(G_MotorPid.SPD_Uq>(26000-(G_Motor_State.Up_Current_Sensitivity<<6))) //18000+x*64
				{
					currentover_count++;
					if(currentover_count>500)
					{
						G_Motor_State.RUN_STATE = 3;
						TURN_FLAG = 1;
						currentover_flag=1;
						currentover_num++;
						currentover_count = 0;
					}
						
				}
				else
					currentover_count=0;
			
    }
//		GPIOB->ODR ^= GPIO_Pin_0;
}

void SysTick_Handler(void)
{
  static uint16_t tim3_1ms,currentover_time,linkage_time;
	if(G_Motor_State.RUN_STATE_1_FLAG == 1 )//先开闸，延迟启动
	{
		if(ERROR_FLAG==0)
		{
			if(Motor_Start_msDelay++>3 )
			{
				G_Motor_State.RUN_STATE = 1;
				Motor_Start_msDelay = 0;
				G_Motor_State.RUN_STATE_1_FLAG=0;
			}
		}
		else
		{
			G_Motor_State.RUN_STATE_1_FLAG=0;
			BRAKE_OFF;
		}
	}
	if(currentover_flag==1)//遇阻反弹
	{
		if(currentover_time++>3800)
		{
//			currentover_flag=2;//悬停一段时间，再继续上升
			currentover_time=0;
			if(currentover_num<3)
				TURN_FLAG = 1;
			else
				currentover_flag = 0,currentover_num=0;
			G_Motor_State.RUN_STATE = 3;
			currentover_flag = 0;
		}
	}
	if(G_Motor_State.STOP_STATE_FLAG == 1)//延迟关闸
	{
		if(Motor_Stop_msDelay++>2000)
		{
			BRAKE_OFF;
			Motor_Stop_msDelay=0;
			motor_svpwm(0,0,G_Motor_State.DIR);
			G_Motor_State.STOP_STATE_FLAG = 0;
		}
		
	}
	if(G_Motor_State.SET_MODEL || G_Motor_State.Limit_Set_Flag)//设置模式下
	{
		SET_TIME++;//设置基准时间
		if(SET_TIME>20000 && REMOTE_FLAG ==1)//超时未操作，退出设置模式(REMOTE_FLAG遥控器进入设置行程模式标志位)
		{
			SET_TIME=0;
			REMOTE_FLAG=0;
			Buzzer_Run_Count=2,Buzzer_Flag =1;
			G_Motor_State.SET_MODEL = 0;
			G_Motor_State.Limit_Set_Flag = 0;
			GPIOB->ODR |= GPIO_Pin_0;
		}
		tim3_1ms++;//闪灯基准时间
		if(tim3_1ms>=150)
		GPIOB->ODR ^= GPIO_Pin_0,tim3_1ms=0;
	}
	if(G_Motor_State.Limit_Set_Flag==1 || G_MotorPid.Pos_Up_Setter_Flag==0 || G_MotorPid.Pos_Down_Setter_Flag==0)//点动
	{
		Limit_Set_ms++;
		if(Limit_Set_ms>=300)//按键松开
		{
			if(G_Motor_State.RUN_STATE)
				G_Motor_State.RUN_STATE = 3;
			Limit_Set_ms=0;
		}
			
	}
	else if(G_Motor_State.Screen_Linkage_Flag && G_Motor_State.Screen_Linkage_Start)
	{
		if(linkage_time++>5000)
		{
			if(G_Motor_State.DIR ^ G_Motor_State.polarity)
			{
				Screen_Motor2_Up();
				Screen_Motor1_Up(80);
			}
			else
			{
				Screen_Motor2_Down();
				Screen_Motor1_Down(80);
			}
			G_Motor_State.Screen_Linkage_Start = 0;
			linkage_time = 0;
		}
		
	}
	if(KEY1_UP_COUNT)
	{
		if(linkage_time++>800)
			KEY1_UP_COUNT=0,linkage_time=0;
	}
	run_test();
	hall_time++;
	RX_ms++;
}

/*掉电检测*/
void EXTI1_IRQHandler(void)
{
	if (EXTI_GetITStatus(EXTI_Line1) == SET)		//判断是否是外部中断14号线触发的中断
	{
		motor_svpwm(18000,0,G_Motor_State.DIR);
		G_Motor_State.RUN_STATE=0;
		BRAKE_OFF;
		Store_Data[0] = G_MotorPid.Pos_Back>>16;//当前位置
		Store_Data[1] = G_MotorPid.Pos_Back;
		Store_Data[2] = G_MotorPid.Pos_Up_Setter>>16;//上限设置值
		Store_Data[3] = G_MotorPid.Pos_Up_Setter;
		Store_Data[4] = G_MotorPid.Pos_Down_Setter>>16;//下限设置值
		Store_Data[5] = G_MotorPid.Pos_Down_Setter;
		Store_Data[6] = G_Motor_State.Pos_Up_Arrive_Flag;//到达上限位标志位
		Store_Data[7] = G_Motor_State.Pos_Down_Arrive_Flag;//到达下限位标志位
		Store_Data[15] = G_MotorPid.Pos_Up_Setter_Flag;//上限设置标志位
		Store_Data[16] = G_MotorPid.Pos_Down_Setter_Flag;//下限设置标志位
		
	  Store_Data[11] = G_MotorParam.up_speed_set;//速度
		Store_Data[12] = G_MotorParam.down_speed_set;//速度
		Store_Data[13] = G_MotorPid.Pos_win>>16;//开窗行程
		Store_Data[14] = G_MotorPid.Pos_win;//开窗行程
		
		/*对码*/
		Store_Data[8] = eq1_check[0];
		Store_Data[9] = eq1_check[1];
		Store_Data[10] = eq1_check[2];
		
		/*电流限制-灵敏度*/
		Store_Data[17] = G_Motor_State.Down_Current_Limit;
		Store_Data[18] = G_Motor_State.Up_Current_Limit;
		Store_Data[19] = G_Motor_State.Down_Current_Sensitivity;
		Store_Data[20] = G_Motor_State.Up_Current_Sensitivity;
		
		Store_Data[21] = G_MotorPid.Pos_little_win>>16;
		Store_Data[22] = G_MotorPid.Pos_little_win;
		Store_Data[23] = G_Motor_State.polarity;
		Store_Save();
		motor_svpwm(0,0,G_Motor_State.DIR);
		EXTI_ClearITPendingBit(EXTI_Line1);		//清除外部中断14号线的中断标志位
											
	}
}
