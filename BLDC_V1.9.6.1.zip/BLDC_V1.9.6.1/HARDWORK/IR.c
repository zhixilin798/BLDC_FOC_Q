#include "IR.h"

uint8_t IR_Data[6],IR_Addr,IR_Com;
uint8_t IR_STATE=0,IR_pData=0,IR_FLAG=0,IR_PASSWORD_FLAG=0,REMOTE_FLAG=0,TURN_FLAG=0;
uint16_t IR_Time;
uint8_t last_addr_com[2];
uint8_t eq1_check[3],eq2_check[3];
uint32_t Limit_Set_ms;
uint16_t Pos_Comp=50;
uint16_t KEY4_DOWN_COUNT;
uint16_t SET_TIME,KEY1_TIME,KEY2_TIME,KEY2_DOWN_COUNT,KEY1_UP_COUNT;
extern uint8_t currentover_flag,currentover_num;
void IR_Con(uint8_t *ir_flag)
{
	if(*ir_flag)
	{
		if(IR_Addr==0x21 )//左边按键
		switch(IR_Com){
			case KEY1_DOWN://按键1按下
				if(G_Motor_State.Limit_Set_Flag==1 || G_MotorPid.Pos_Up_Setter_Flag==0 || G_MotorPid.Pos_Down_Setter_Flag==0)//点动状态抬起按键立马停
				{
					SET_TIME=0;
					Limit_Set_ms=0;
					if(G_Motor_State.RUN_STATE==0 )
					{
						if(G_Motor_State.polarity && G_Motor_State.Pos_Down_Arrive_Flag==0)//方向为1，未到下限位
						{
							G_Motor_State.Pos_Up_Arrive_Flag = 0;
							G_Motor_State.DIR=0;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
							currentover_flag=0;
						}
						else if(G_Motor_State.polarity==0 && G_Motor_State.Pos_Up_Arrive_Flag==0)//方向为0，未到上限位
						{
							G_Motor_State.Pos_Down_Arrive_Flag = 0;
							G_Motor_State.DIR=1;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
						}
					}
				}
				else
				{
					if(G_Motor_State.RUN_STATE==0 )
					{
						if(G_Motor_State.polarity && G_Motor_State.Pos_Down_Arrive_Flag==0)//方向为1，未到下限位
						{
							G_Motor_State.Pos_Up_Arrive_Flag = 0;
							G_Motor_State.DIR=0;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							G_Motor_State.Screen_Linkage_Start=1;
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
							currentover_flag=0;
						}
						else if(G_Motor_State.polarity==0 && G_Motor_State.Pos_Up_Arrive_Flag==0)//方向为0，未到上限位
						{
							G_Motor_State.Pos_Down_Arrive_Flag = 0;
							G_Motor_State.DIR=1;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							G_Motor_State.Screen_Linkage_Start=1;
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
							
						}
					}
					else if(G_Motor_State.RUN_STATE==2)//运行过程中反向启动
					{
						if(G_Motor_State.polarity && G_Motor_State.DIR==1)
							TURN_FLAG = 1,G_Motor_State.RUN_STATE = 3;
						if(G_Motor_State.polarity==0 && G_Motor_State.DIR==0)
							TURN_FLAG = 1,G_Motor_State.RUN_STATE = 3;
					}
				}
					break;

			case KEY2_UP://按键2按下/松开
					SET_TIME=0;
					if(G_Motor_State.RUN_STATE == 2)
					{
						G_Motor_State.RUN_STATE = 3;
						currentover_flag = 0;
						currentover_num = 0;
					}
					if(G_Motor_State.Limit_Set_Flag)//行程设置模式下长按切换方向
						if(KEY2_DOWN_COUNT++>15)
						{
							G_Motor_State.polarity=!G_Motor_State.polarity;
							Buzzer_Flag = 1,Buzzer_Run_Count=2;
							KEY2_DOWN_COUNT=0;
						}
					break;
			case KEY3_DOWN://按键3按下
				if(G_Motor_State.Limit_Set_Flag==1 || G_MotorPid.Pos_Up_Setter_Flag==0 || G_MotorPid.Pos_Down_Setter_Flag==0)//点动状态抬起按键立马停
				{
					SET_TIME=0;
					Limit_Set_ms=0;
					if(G_Motor_State.RUN_STATE==0)
					{
						if(G_Motor_State.polarity && G_Motor_State.Pos_Up_Arrive_Flag==0)//方向为1，未到上限位
						{
							G_Motor_State.Pos_Down_Arrive_Flag=0;
							G_Motor_State.DIR=1;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							G_Motor_State.Screen_Linkage_Start=1;
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
						}
						else if(G_Motor_State.polarity==0 && G_Motor_State.Pos_Down_Arrive_Flag==0)//方向为0，未到下限位
						{
							G_Motor_State.Pos_Up_Arrive_Flag = 0;
							G_Motor_State.DIR=0;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							G_Motor_State.Screen_Linkage_Start=1;
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
							currentover_flag=0;
						}
					}
				}
				else
				{
					if(G_Motor_State.RUN_STATE==0)
					{
						if(G_Motor_State.polarity && G_Motor_State.Pos_Up_Arrive_Flag==0)//方向为1，未到上限位
						{
							G_Motor_State.Pos_Down_Arrive_Flag=0;
							G_Motor_State.DIR=1;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							G_Motor_State.Screen_Linkage_Start=1;
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
						}
						else if(G_Motor_State.polarity==0 && G_Motor_State.Pos_Down_Arrive_Flag==0)//方向为0，未到下限位
						{
							G_Motor_State.Pos_Up_Arrive_Flag = 0;
							G_Motor_State.DIR=0;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							BRAKE_ON;//开闸
							G_Motor_State.Screen_Linkage_Start=1;
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
							currentover_flag=0;
						}
					}
					else if(G_Motor_State.RUN_STATE==2)//运行过程中反向启动
					{ 
						if(G_Motor_State.polarity && G_Motor_State.DIR==0)
							TURN_FLAG = 1,G_Motor_State.RUN_STATE = 3;
						if(G_Motor_State.polarity==0 && G_Motor_State.DIR==1)
							TURN_FLAG = 1,G_Motor_State.RUN_STATE = 3;
					}
				}
				
					break;
			case KEY4_DOWN://按键4按下,进入设置状态
					if(KEY4_DOWN_COUNT++>=15)
					{
						REMOTE_FLAG=1;
						G_Motor_State.SET_MODEL = 1;
						G_Motor_State.Limit_Set_Flag = 1;
						SET_TIME = 0;
						G_MotorPid.Pos_Down_Setter_Flag = 0;
						G_MotorPid.Pos_Up_Setter_Flag = 0;
						KEY4_DOWN_COUNT=0;
						Buzzer_Run_Count=3,Buzzer_Flag = 1;
					}
					break;
			case KEY1_UP://加速判定
				if(G_Motor_State.Limit_Set_Flag==0 && G_MotorPid.Pos_Up_Setter_Flag==1 && G_MotorPid.Pos_Down_Setter_Flag==1)//已有行程状态
					KEY1_UP_COUNT++;
				if(KEY1_UP_COUNT>=3)
					G_Motor_State.Fast_Run_flag=1;
				break;
			case KEY3_UP://加速判定
			if(G_Motor_State.Limit_Set_Flag==0 && G_MotorPid.Pos_Up_Setter_Flag==1 && G_MotorPid.Pos_Down_Setter_Flag==1)//已有行程状态
				KEY1_UP_COUNT++;
			if(KEY1_UP_COUNT>=3)
				G_Motor_State.Fast_Run_flag=1;
			break;
			default:
					break;
		}
		if(IR_Addr==0x32)
		{
			if(G_Motor_State.Limit_Set_Flag==0)//非设置模型下控制有刷电机
			{
				switch(IR_Com){
					case KEY1_UP:
							Screen_Motor1_Up(80);
							Screen_Motor2_Up();
							break;
					case KEY2_UP:
							Screen_Motor1_Stop();
							Screen_Motor2_Stop();
							break;
					case KEY3_UP:
							Screen_Motor1_Down(80);
							Screen_Motor2_Down();
							break;
				}
			}
			else/*设置模式下---对码和上下限位设置进入设置模式状态*/
			{
				SET_TIME=0;
				switch(IR_Com){
					case KEY1_DOWN://按键1按下
						if(KEY1_TIME++>=15 && REMOTE_FLAG ==1)//遥控器进入设置
						{
							KEY1_TIME = 0;
							if(G_Motor_State.polarity)
							{
								Buzzer_Run_Count=1,Buzzer_Flag = 1;
								G_MotorPid.Pos_Down_Setter = G_MotorPid.Pos_Back - Pos_Comp;
								G_MotorPid.Pos_Down_Setter_Flag = 1;
								if(G_MotorPid.Pos_Up_Setter_Flag == 1)//设置完毕
								{
									if(G_Motor_State.polarity)
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Up_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Up_Setter;
									else
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Down_Setter;
									G_MotorPid.Pos_little_win = G_MotorPid.Pos_Down_Setter + (50*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
									Buzzer_Run_Count=2,Buzzer_Flag =1;
									G_Motor_State.SET_MODEL = 0;
									G_Motor_State.Limit_Set_Flag = 0;
									REMOTE_FLAG=0;
									GPIOB->ODR |= GPIO_Pin_0;
								}
							}
							else
							{
								Buzzer_Run_Count=1,Buzzer_Flag = 1;
								G_MotorPid.Pos_Up_Setter = G_MotorPid.Pos_Back + Pos_Comp;
								G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Back + Pos_Comp;
								G_MotorPid.Pos_Up_Setter_Flag = 1;
								if(G_MotorPid.Pos_Down_Setter_Flag == 1)//设置完毕
								{
									if(G_Motor_State.polarity)
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Up_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Up_Setter;
									else
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Down_Setter;
									G_MotorPid.Pos_little_win = G_MotorPid.Pos_Down_Setter + (50*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
									Buzzer_Run_Count=2,Buzzer_Flag = 1;
									G_Motor_State.SET_MODEL = 0;
									G_Motor_State.Limit_Set_Flag = 0;
									REMOTE_FLAG=0;
									GPIOB->ODR |= GPIO_Pin_0;
								}
							}
						}
						else if(REMOTE_FLAG == 0)//屏幕进入设置
						{
							if(G_Motor_State.polarity)
							{
								Buzzer_Run_Count=1,Buzzer_Flag = 1;
								G_MotorPid.Pos_Down_Setter = G_MotorPid.Pos_Back - Pos_Comp;
								G_MotorPid.Pos_Down_Setter_Flag = 1;
								if(G_MotorPid.Pos_Up_Setter_Flag == 1)//设置完毕
								{
									if(G_Motor_State.polarity)
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Up_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Up_Setter;
									else
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Down_Setter;
									G_MotorPid.Pos_little_win = G_MotorPid.Pos_Down_Setter + (50*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
									Buzzer_Run_Count=2,Buzzer_Flag =1;
									G_Motor_State.SET_MODEL = 0;
									G_Motor_State.Limit_Set_Flag = 0;
									REMOTE_FLAG=0;
									GPIOB->ODR |= GPIO_Pin_0;
								}
							}
							else
							{
								Buzzer_Run_Count=1,Buzzer_Flag = 1;
								G_MotorPid.Pos_Up_Setter = G_MotorPid.Pos_Back + Pos_Comp;
								G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Back + Pos_Comp;
								G_MotorPid.Pos_Up_Setter_Flag = 1;
								if(G_MotorPid.Pos_Down_Setter_Flag == 1)//设置完毕
								{
									if(G_Motor_State.polarity)
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Up_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Up_Setter;
									else
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Down_Setter;
									G_MotorPid.Pos_little_win = G_MotorPid.Pos_Down_Setter + (50*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
									Buzzer_Run_Count=2,Buzzer_Flag = 1;
									G_Motor_State.SET_MODEL = 0;
									G_Motor_State.Limit_Set_Flag = 0;
									REMOTE_FLAG=0;
									GPIOB->ODR |= GPIO_Pin_0;
								}
							}
						}
							break;
					case KEY1_UP://按键1抬起
							KEY1_TIME=0;
					case KEY2_DOWN://按键2按下/松开
		//					G_Motor_State.RUN_STATE = 3;
							break;
					case KEY3_DOWN://按键3抬起
							if(KEY2_TIME++>=15 && REMOTE_FLAG==1)//长按
							{
								KEY2_TIME = 0;
								if(G_Motor_State.polarity)
								{
									Buzzer_Run_Count=1,Buzzer_Flag = 1;
									G_MotorPid.Pos_Up_Setter = G_MotorPid.Pos_Back + Pos_Comp;
									G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Back + Pos_Comp;
									G_MotorPid.Pos_Up_Setter_Flag = 1;
									if(G_MotorPid.Pos_Down_Setter_Flag)//设置完毕
									{
										if(G_Motor_State.polarity)
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Up_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Up_Setter;
									else
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Down_Setter;
										G_MotorPid.Pos_little_win = G_MotorPid.Pos_Down_Setter + (50*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
										Buzzer_Run_Count=2,Buzzer_Flag = 1;
										G_Motor_State.SET_MODEL = 0;
										G_Motor_State.Limit_Set_Flag = 0;
										GPIOB->ODR |= GPIO_Pin_0;
									}
								}
								else
								{
									Buzzer_Run_Count=1,Buzzer_Flag = 1;
									G_MotorPid.Pos_Down_Setter = G_MotorPid.Pos_Back - Pos_Comp;
									G_MotorPid.Pos_Down_Setter_Flag = 1;
									if(G_MotorPid.Pos_Up_Setter_Flag == 1)//设置完毕
									{
										if(G_Motor_State.polarity)
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Up_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Up_Setter;
									else
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Down_Setter;
										G_MotorPid.Pos_little_win = G_MotorPid.Pos_Down_Setter + (50*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
										Buzzer_Run_Count=2,Buzzer_Flag = 1;
										G_Motor_State.SET_MODEL = 0;
										G_Motor_State.Limit_Set_Flag = 0;
										GPIOB->ODR |= GPIO_Pin_0;
									}
								}
							}
							else if(REMOTE_FLAG == 0)//屏幕进入设置
							{
								if(G_Motor_State.polarity)
								{
									Buzzer_Run_Count=1,Buzzer_Flag = 1;
									G_MotorPid.Pos_Up_Setter = G_MotorPid.Pos_Back + Pos_Comp;
									G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Back + Pos_Comp;
									G_MotorPid.Pos_Up_Setter_Flag = 1;
									if(G_MotorPid.Pos_Down_Setter_Flag)//设置完毕
									{
										if(G_Motor_State.polarity)
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Up_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Up_Setter;
									else
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Down_Setter;
										G_MotorPid.Pos_little_win = G_MotorPid.Pos_Down_Setter + (50*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
										Buzzer_Run_Count=2,Buzzer_Flag = 1;
										G_Motor_State.SET_MODEL = 0;
										G_Motor_State.Limit_Set_Flag = 0;
										GPIOB->ODR |= GPIO_Pin_0;
									}
								}
								else
								{
									Buzzer_Run_Count=1,Buzzer_Flag = 1;
									G_MotorPid.Pos_Down_Setter = G_MotorPid.Pos_Back - Pos_Comp;
									G_MotorPid.Pos_Down_Setter_Flag = 1;
									if(G_MotorPid.Pos_Up_Setter_Flag == 1)//设置完毕
									{
										if(G_Motor_State.polarity)
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Up_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Up_Setter;
									else
										G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter,G_MotorPid.Pos_win = G_MotorPid.Pos_Down_Setter;
										G_MotorPid.Pos_little_win = G_MotorPid.Pos_Down_Setter + (50*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
										Buzzer_Run_Count=2,Buzzer_Flag = 1;
										G_Motor_State.SET_MODEL = 0;
										G_Motor_State.Limit_Set_Flag = 0;
										GPIOB->ODR |= GPIO_Pin_0;
									}
								}
							}
							break;
						case KEY3_UP://按键3抬起
							break;
						case KEY4_DOWN://按键3按下
					default:
							break;
				}
			}
		}
	  if(IR_Addr == DEVICE_ADDR4 && G_Motor_State.Little_Open_Flag == 0)//雨感
		{
			if(IR_Com>=0x77)
			{ 
				if(G_Motor_State.Limit_Set_Flag==1 || G_MotorPid.Pos_Up_Setter_Flag==0 || G_MotorPid.Pos_Down_Setter_Flag==0)//点动状态抬起按键立马停
				{
					SET_TIME=0;
					Limit_Set_ms=0;
					if(G_Motor_State.RUN_STATE==0 )
					{
						if(G_Motor_State.polarity && G_Motor_State.Pos_Down_Arrive_Flag==0)//方向为1，未到下限位
						{
							G_Motor_State.Pos_Up_Arrive_Flag = 0;
							G_Motor_State.DIR=0;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
							currentover_flag=0;
						}
						else if(G_Motor_State.polarity==0 && G_Motor_State.Pos_Up_Arrive_Flag==0)//方向为0，未到上限位
						{
							G_Motor_State.Pos_Down_Arrive_Flag = 0;
							G_Motor_State.DIR=1;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
						}
					}
				}
				else
				{
					if(G_Motor_State.RUN_STATE==0 )
					{
						if(G_Motor_State.polarity && G_Motor_State.Pos_Down_Arrive_Flag==0)//方向为1，未到下限位
						{
							G_Motor_State.Pos_Up_Arrive_Flag = 0;
							G_Motor_State.DIR=0;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
							currentover_flag=0;
						}
						else if(G_Motor_State.polarity==0 && G_Motor_State.Pos_Up_Arrive_Flag==0)//方向为0，未到上限位
						{
							G_Motor_State.Pos_Down_Arrive_Flag = 0;
							G_Motor_State.DIR=1;
							G_Motor_State.RUN_STATE_1_FLAG = 1;
//							motor_svpwm(6000,6000,G_Motor_State.DIR);
							BRAKE_ON;//开闸
							G_Motor_State.STOP_STATE_FLAG=0,Motor_Stop_msDelay=0;//防止意外关闸
							
						}
					}
					else if(G_Motor_State.RUN_STATE==2)//运行过程中反向启动
					{
						if(G_Motor_State.polarity && G_Motor_State.DIR==1)
							TURN_FLAG = 1,G_Motor_State.RUN_STATE = 3;
						if(G_Motor_State.polarity==0 && G_Motor_State.DIR==0)
							TURN_FLAG = 1,G_Motor_State.RUN_STATE = 3;
					}
				}
			}
		}
		*ir_flag=0;
	}
}

//void IR_Data_Process(void)
//{
//	if(IR_FLAG)
//	{
//		if(IR_Addr==KEY1_ADDR)
//		{
//			switch(IR_Com){
//				case KEY1_UP://按键1按下
//						if(G_Motor_State.RUN_STATE ==2)//电机正在转动
//							G_Motor_State.Turn_Flag=1;
//						else
//						{
//							G_Motor_State.DIR = 1;
//							G_Motor_State.RUN_STATE = 1;
//						}
//				break;
//				case KEY1_DOWN://按键1松开
//						G_Motor_State.DIR = 1;
//						G_Motor_State.RUN_STATE = 1;
//				case KEY2_UP://按键2按下/松开
//						if(G_Motor_State.RUN_STATE == 2)
//							G_Motor_State.RUN_STATE = 3;
//				break;
//				case KEY3_UP://按键3按下
//						if(G_Motor_State.RUN_STATE ==2)//电机正在转动
//							G_Motor_State.Turn_Flag=1;
//						else
//						{
//							G_Motor_State.DIR = 0;
//							G_Motor_State.RUN_STATE = 1;
//						}
//				break;
//			}
//		}
//		
//		last_addr_com[0] = IR_Addr;
//		last_addr_com[1] = IR_Com;
//	}
//}

void EXTI15_10_IRQHandler(void)
{

	if (EXTI_GetITStatus(EXTI_Line10) == SET)		
	{
		EXTI_ClearITPendingBit(EXTI_Line10);		
		
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10))//上升沿
		{
			TIM4->CNT=0;
		}
		else//下降沿
		{
			if(IR_STATE==0)//等待start信号
			{
				IR_Time = TIM4->CNT;
				if(IR_Time>=4700 && IR_Time<=4900)//起始信号判断
					IR_STATE=1;
			}
			else if(IR_STATE==1)//数据信号处理
			{
				IR_Time = TIM4->CNT;
				if(IR_Time>=650 && IR_Time<=790)//接收到了数据1
				{
					IR_Data[IR_pData/8]|=(0x80>>(IR_pData%8));	//数据对应位置1
					IR_pData++;			//数据位置指针自增
				}
				else if(IR_Time>=308 && IR_Time<=448)//接收到了数据0
				{
					IR_Data[IR_pData/8]&=~(0x80>>(IR_pData%8));	//数据对应位清0
					IR_pData++;			//数据位置指针自增
				}
				else//数据错误
				{
					IR_pData=0;			//数据位置指针清0
					IR_STATE=0;			//置状态为1
				}
				if(IR_pData>=40) //数据接收完成
				{
					IR_pData=0;
					
					if(IR_Data[0]==eq1_check[0] && IR_Data[1]==eq1_check[1] && IR_Data[2]==eq1_check[2])//数据验证
					{
						IR_Addr = IR_Data[3];
						IR_Com = IR_Data[4];
						IR_FLAG = 1;
					}
					else if(IR_Data[0]==eq2_check[0] && IR_Data[1]==eq2_check[1] && IR_Data[2]==eq2_check[2])//数据验证
					{
						IR_Addr = IR_Data[3];
						IR_Com = IR_Data[4];
						IR_FLAG = 1;
					}
					if(IR_PASSWORD_FLAG)//按键对码
					{
						if(IR_Data[0]!=0 && IR_Data[3]==0x21 && IR_Data[4]==0x55)//遥控器
						{
							eq1_check[0] = IR_Data[0],eq1_check[1] = IR_Data[1],eq1_check[2] = IR_Data[2],IR_PASSWORD_FLAG=0,G_Motor_State.SET_MODEL = 0;
							Buzzer_Run_Count = 2,Buzzer_Flag = 1;
							REMOTE_FLAG = 0;
							GPIOB->ODR |= GPIO_Pin_0;
						}
						else if(IR_Data[0]==0 && IR_Data[3]==0x01 && IR_Data[4]==0x11)//雨感
						{
							eq2_check[0] = IR_Data[0],eq2_check[1] = IR_Data[1],eq2_check[2] = IR_Data[2],IR_PASSWORD_FLAG=0,G_Motor_State.SET_MODEL = 0;
							Buzzer_Run_Count = 2,Buzzer_Flag = 1;
							GPIOB->ODR |= GPIO_Pin_0;
						}
							
					}
				}
			}
		}
	}
}
