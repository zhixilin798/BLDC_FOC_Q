#include "Function.h"

const int16_t IQSin_Cos_Table[256]={\
0x0000,0x00C9,0x0192,0x025B,0x0324,0x03ED,0x04B6,0x057F,\
0x0648,0x0711,0x07D9,0x08A2,0x096A,0x0A33,0x0AFB,0x0BC4,\
0x0C8C,0x0D54,0x0E1C,0x0EE3,0x0FAB,0x1072,0x113A,0x1201,\
0x12C8,0x138F,0x1455,0x151C,0x15E2,0x16A8,0x176E,0x1833,\
0x18F9,0x19BE,0x1A82,0x1B47,0x1C0B,0x1CCF,0x1D93,0x1E57,\
0x1F1A,0x1FDD,0x209F,0x2161,0x2223,0x22E5,0x23A6,0x2467,\
0x2528,0x25E8,0x26A8,0x2767,0x2826,0x28E5,0x29A3,0x2A61,\
0x2B1F,0x2BDC,0x2C99,0x2D55,0x2E11,0x2ECC,0x2F87,0x3041,\
0x30FB,0x31B5,0x326E,0x3326,0x33DF,0x3496,0x354D,0x3604,\
0x36BA,0x376F,0x3824,0x38D9,0x398C,0x3A40,0x3AF2,0x3BA5,\
0x3C56,0x3D07,0x3DB8,0x3E68,0x3F17,0x3FC5,0x4073,0x4121,\
0x41CE,0x427A,0x4325,0x43D0,0x447A,0x4524,0x45CD,0x4675,\
0x471C,0x47C3,0x4869,0x490F,0x49B4,0x4A58,0x4AFB,0x4B9D,\
0x4C3F,0x4CE0,0x4D81,0x4E20,0x4EBF,0x4F5D,0x4FFB,0x5097,\
0x5133,0x51CE,0x5268,0x5302,0x539B,0x5432,0x54C9,0x5560,\
0x55F5,0x568A,0x571D,0x57B0,0x5842,0x58D3,0x5964,0x59F3,\
0x5A82,0x5B0F,0x5B9C,0x5C28,0x5CB3,0x5D3E,0x5DC7,0x5E4F,\
0x5ED7,0x5F5D,0x5FE3,0x6068,0x60EB,0x616E,0x61F0,0x6271,\
0x62F1,0x6370,0x63EE,0x646C,0x64E8,0x6563,0x65DD,0x6656,\
0x66CF,0x6746,0x67BC,0x6832,0x68A6,0x6919,0x698B,0x69FD,\
0x6A6D,0x6ADC,0x6B4A,0x6BB7,0x6C23,0x6C8E,0x6CF8,0x6D61,\
0x6DC9,0x6E30,0x6E96,0x6EFB,0x6F5E,0x6FC1,0x7022,0x7083,\
0x70E2,0x7140,0x719D,0x71F9,0x7254,0x72AE,0x7307,0x735E,\
0x73B5,0x740A,0x745F,0x74B2,0x7504,0x7555,0x75A5,0x75F3,\
0x7641,0x768D,0x76D8,0x7722,0x776B,0x77B3,0x77FA,0x783F,\
0x7884,0x78C7,0x7909,0x794A,0x7989,0x79C8,0x7A05,0x7A41,\
0x7A7C,0x7AB6,0x7AEE,0x7B26,0x7B5C,0x7B91,0x7BC5,0x7BF8,\
0x7C29,0x7C59,0x7C88,0x7CB6,0x7CE3,0x7D0E,0x7D39,0x7D62,\
0x7D89,0x7DB0,0x7DD5,0x7DFA,0x7E1D,0x7E3E,0x7E5F,0x7E7E,\
0x7E9C,0x7EB9,0x7ED5,0x7EEF,0x7F09,0x7F21,0x7F37,0x7F4D,\
0x7F61,0x7F74,0x7F86,0x7F97,0x7FA6,0x7FB4,0x7FC1,0x7FCD,\
0x7FD8,0x7FE1,0x7FE9,0x7FF0,0x7FF5,0x7FF9,0x7FFD,0x7FFE}; 


PLL_Param_t			PLL_Param;
Motor_State_t 		G_Motor_State;
MotorParam_t		G_MotorParam;
MotorPid_t			G_MotorPid;

IPARK        IparkU;
SVPWM        Svpwmdq;
IQSin_Cos    AngleSin_Cos;
uint16_t last_angle;
uint16_t Motor_Start_msDelay;
uint16_t Motor_Stop_msDelay;
uint16_t Sys_State_1=0,Sys_State_2=0;
uint8_t ERROR_FLAG=0;
void MOTOR_PARA_Init()
{
//	G_Motor_State.Hall_State = 
	G_Motor_State.Motor_Fault = 0;
	G_Motor_State.RUN_STATE = 0;
	G_MotorParam.startDuty = 1000;//启动ccr
	G_MotorParam.pullFreq_Hz = 1000;//启动频率
//	G_MotorParam.overCurrent = ;	//阈值电流
//	G_MotorParam.overvoltage = ;	//阈值电压
	G_MotorParam.stallTimeout_ms = 100;//堵转时间阈值ms
//	G_MotorParam.polePairs = ;//极对数
//	G_MotorPid.KD_CUR = ;
//	G_MotorPid.KI_CUR = ;
//	G_MotorPid.KP_CUR = ;
//	G_MotorPid.KI_SPD = ;
//	G_MotorPid.KP_SPD = ;
//	G_MotorPid.KP_POS = ;
//	G_MotorPid.PI_Max = ;
//	G_MotorPid.PI_Min = ;
//	G_MotorPid.PI_Max = ;
//	G_MotorPid.PI_Min = ;
//	G_MotorPid.UMax = ;
//	G_MotorPid.UMin = ;

}
/* -------------------- 1. PLL参数定义 -------------------- */
// 环路带宽250 rad/s（约39.8Hz），临界阻尼设计（ζ=1）
#define SpeedPllBandwidth 250.0f            // 单位：rad/s

// 比例增益 Kp = 2ωn = 2 * 250 = 500，Q15格式约化为int16_t
#define SpeedPllKp        (int16_t)(2 * SpeedPllBandwidth)

// 积分增益 Ki = ωn² * Ts = 250² * (1/PWM_FREQ/1000)，Q15格式
// Ts为采样周期，需根据实际PWM频率计算
#define SpeedPllKi        (int16_t)(SpeedPllBandwidth * SpeedPllBandwidth / PWM_FREQ / 1000.0f)

// 速度→角度转换系数：每Ts积分产生的角度增量
// OmegaToTheta = 16384 * 32768 / (PWM_FREQ*1000*π) = 2^14 * 2^15 / (fs*π)
#define OmegaToTheta      (int16_t)(16384.0f * 32768.0f / PWM_FREQ / 1000.0f / PI)


void SpeedPll(void)
{
	PLL_Param.PLL_Kp = 1;
	PLL_Param.PLL_Ki = 1;
	PLL_Param.Integral_Limit = 65535;
	
	PLL_Param.Angle_Error = (PLL_Param.PLL_Angle - AngleSin_Cos.IQAngle);//误差
	
	PLL_Param.PLL_Anhgle_Integral += PLL_Param.PLL_Ki*PLL_Param.Angle_Error;//积分
	if(PLL_Param.PLL_Anhgle_Integral > PLL_Param.Integral_Limit)//积分限幅
		PLL_Param.PLL_Anhgle_Integral = PLL_Param.Integral_Limit;
	else if(PLL_Param.PLL_Anhgle_Integral < -PLL_Param.Integral_Limit)
		PLL_Param.PLL_Anhgle_Integral = -PLL_Param.Integral_Limit;
	
	PLL_Param.PLL_Angle += PLL_Param.PLL_Kp*PLL_Param.Angle_Error + PLL_Param.PLL_Anhgle_Integral;
}
//电机启动控制
void MOTOR_START(void)
{
	static uint8_t temp_count;
	if(temp_count++>=10)
	{
		G_MotorPid.PWM_Duty++;
		temp_count=0;
	}
	if(G_MotorPid.PWM_Duty >= G_MotorPid.Up_overduty)
		G_Motor_State.RUN_STATE = 2;//进入闭环
	
}

void  SVPWM_Cale(p_SVPWM  pV)
{
  pV->tmp1= pV->Ubeta;
	pV->tmp2= _IQdiv2(pV->Ubeta) + _IQmpy(28377,pV->Ualpha); //     _IQ(0.866)
  pV->tmp3= pV->tmp2 - pV->tmp1;

	pV->VecSector=3;
	pV->VecSector=(pV->tmp2> 0)?( pV->VecSector-1):pV->VecSector;
	pV->VecSector=(pV->tmp3> 0)?( pV->VecSector-1):pV->VecSector;
	pV->VecSector=(pV->tmp1< 0)?(7-pV->VecSector) :pV->VecSector;

	 if  (pV->VecSector==1 || pV->VecSector==4)
      {  
				pV->Ta= pV->tmp2;
      	pV->Tb= pV->tmp1-pV->tmp3;
      	pV->Tc=-pV->tmp2;
      }

   else if(pV->VecSector==2 || pV->VecSector==5)
      {  
				pV->Ta= pV->tmp3+pV->tmp2;
      	pV->Tb= pV->tmp1;
      	pV->Tc=-pV->tmp1;
      }

    else
      {   
				pV->Ta= pV->tmp3;
      	pV->Tb=-pV->tmp3;
      	pV->Tc=-(pV->tmp1+pV->tmp2);
      }
}
int16_t  PWM_DUTY[3]={0,0,0};
void  Svpwm_Outpwm(void)
{
   PWM_DUTY[0]= _IQmpy(PWM_HalfPerMax,Svpwmdq.Ta)+ PWM_HalfPerMax;
   PWM_DUTY[1]= _IQmpy(PWM_HalfPerMax,Svpwmdq.Tb)+ PWM_HalfPerMax;
	 PWM_DUTY[2]= _IQmpy(PWM_HalfPerMax,Svpwmdq.Tc)+ PWM_HalfPerMax;

	 TIM1->CCR1 = PWM_DUTY[0];//PWM_DUTY[0]  (EQEPPare.JZElecTheta>>5)
   TIM1->CCR2 = PWM_DUTY[1];//PWM_DUTY[1]
   TIM1->CCR3 = PWM_DUTY[2] ;//PWM_DUTY[2]
}
void  IPARK_Cale(p_IPARK pV)    
{
	pV->Alpha = _IQmpy(pV->Ds,pV->Cosine) - _IQmpy( pV->Qs,pV->Sine);
	pV->Beta  = _IQmpy(pV->Qs,pV->Cosine) + _IQmpy(pV->Ds,pV->Sine);
}

void  IQSin_Cos_Cale(p_IQSin_Cos  pV)  
{
  uint16_t  hindex;
  hindex = (uint16_t) pV->IQAngle; //-32768--- 32767 +32768===0--65535
  hindex >>=6;      //65536/64  ===1024/4=90¶È=256 0x01-0xFF  0X100  0X1FF  0X200 0X2FF    0X300  0X3FF
                                                      
  switch (hindex & SIN_RAD)  //  0X300  &   0x0000 -ff    0x0100  1ff   0X200    2ff   0x0300   3ff  
  {
    case U0_90:                        
       pV->IQSin = IQSin_Cos_Table[(uint8_t)(hindex)];  // 0---255  ==0---32766
       pV->IQCos = IQSin_Cos_Table[(uint8_t)(0xFF-(u8)(hindex))];
    break;
  
    case U90_180:  
       pV->IQSin = IQSin_Cos_Table[(u8)(0xFF-(u8)(hindex))]; // 255---0 == 0---32766 
       pV->IQCos = -IQSin_Cos_Table[(u8)(hindex)];
    break;
  
    case U180_270:
       pV->IQSin = -IQSin_Cos_Table[(u8)(hindex)];
       pV->IQCos = -IQSin_Cos_Table[(u8)(0xFF-(u8)(hindex))];
    break;
  
    case U270_360:
     pV->IQSin=  -IQSin_Cos_Table[(u8)(0xFF-(u8)(hindex))];
     pV->IQCos =  IQSin_Cos_Table[(u8)(hindex)]; 
    break;
   default:
    break;
  } 
} 
 

int32_t my_LPF(int32_t value,int32_t last_value)
{
	int32_t data;
	data = value*25/100 + last_value*75/100;
	return data;
}


void Motor_Drag(uint32_t Uq,uint32_t Ud,uint8_t Motor_DIR)
{
	if(Motor_DIR)
	{
	
		IparkU.Ds = -Ud;   //D轴给定
		IparkU.Qs= Uq;  //Q轴给定
		IPARK_Cale((p_IPARK)&IparkU);//反park      
		Svpwmdq.Ualpha =IparkU.Alpha;//α
		Svpwmdq.Ubeta = IparkU.Beta;//β

		SVPWM_Cale((p_SVPWM)&Svpwmdq);    //svpwm 

		Svpwm_Outpwm( ); 
	}
	else
	{
	

		IparkU.Ds = -Ud;   //D轴给定
		IparkU.Qs= -Uq;  //Q轴给定
		IPARK_Cale((p_IPARK)&IparkU);//反park      
		Svpwmdq.Ualpha =IparkU.Alpha;//α
		Svpwmdq.Ubeta = IparkU.Beta;//β

		SVPWM_Cale((p_SVPWM)&Svpwmdq);    //svpwm 

		Svpwm_Outpwm(); 
	}
}


void motor_svpwm(uint32_t Uq,uint32_t Ud,uint8_t Motor_DIR)
{
	if(Motor_DIR)
	{
	
		IparkU.Ds = -Ud;   //D轴给定
		IparkU.Qs= Uq;  //Q轴给定
		IPARK_Cale((p_IPARK)&IparkU);//反park      
		Svpwmdq.Ualpha =IparkU.Alpha;//α
		Svpwmdq.Ubeta = IparkU.Beta;//β

		SVPWM_Cale((p_SVPWM)&Svpwmdq);    //svpwm 

		Svpwm_Outpwm( ); 
	}
	else
	{
	

		IparkU.Ds = -Ud;   //D轴给定
		IparkU.Qs= -Uq;  //Q轴给定
		IPARK_Cale((p_IPARK)&IparkU);//反park      
		Svpwmdq.Ualpha =IparkU.Alpha;//α
		Svpwmdq.Ubeta = IparkU.Beta;//β

		SVPWM_Cale((p_SVPWM)&Svpwmdq);    //svpwm 

		Svpwm_Outpwm(); 
	}
}

uint8_t direction_turn_angle_compensation(uint8_t motor_dir)
{
	static uint8_t last_dir;
	uint8_t dir = motor_dir;
	
	if(last_dir == dir)
		return 0;
	else
	{
		last_dir = dir;
		return 1;
	}
		
}
int32_t my_abs(int32_t value)
{
	if(value>=0)
		return value;
	else
		return -value;
}

int32_t my_fmax(int32_t value1,int32_t value2)
{
		if(value1>=value2)
			return  value1;
		else
			return value2;			
}

void MOTOR_RUN_Start(void)
{
	if(G_Motor_State.RUN_STATE_1_FLAG == 1)
	{
		if(Motor_Start_msDelay>300)
		{
			G_Motor_State.RUN_STATE = 1;
			Motor_Start_msDelay = 0;
			G_Motor_State.RUN_STATE_1_FLAG=0;
		}
	}
}
//状态监测

void SYS_STATE_MONITOR(void)
{
	static uint8_t hall_error_count;
	/*霍尔异常*/
	uint8_t a1 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0);//a
	uint8_t a2 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1);//b
	uint8_t a3 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2);//c
	if(a1==1 && a2==1 && a3==1)
		hall_error_count = 1 ;
	else if(a1==0 && a2==0 && a3==0)
		hall_error_count = 1;
	else
		hall_error_count = 0;
	if(hall_error_count)
		Sys_State_2 |= 0x0004,ERROR_FLAG |= 0x01;
	else
		Sys_State_2 &= ~0x0004,ERROR_FLAG &= ~0x01;
	/*电机异常*/
	/*驱动器异常*/
	if(G_MotorParam.down_speed_set < 800 || G_MotorParam.up_speed_set <800 \
		|| G_MotorParam.down_speed_set > 4800 || G_MotorParam.up_speed_set > 4800)//flash存储故障
		Sys_State_1 |= 0x0400,ERROR_FLAG |= 0x02;
	else
		Sys_State_1 &= ~0x0400,ERROR_FLAG &= ~0x02;
	
	/*限位状态*/
	if(G_Motor_State.polarity)
	{
		if(G_MotorPid.Pos_Up_Setter_Flag)
			Sys_State_1 &= ~0x0002;
		else
			Sys_State_1 |= 0x0002;
		if(G_MotorPid.Pos_Down_Setter_Flag)
			Sys_State_1 &= ~0x0001;
		else
			Sys_State_1 |= 0x0001;
	}
	else
	{
		if(G_MotorPid.Pos_Down_Setter_Flag)
			Sys_State_1 &= ~0x0002;
		else
			Sys_State_1 |= 0x0002;
		if(G_MotorPid.Pos_Up_Setter_Flag)
			Sys_State_1 &= ~0x0001;
		else
			Sys_State_1 |= 0x0001;
	}

}

void run_test(void)
{
	static uint32_t test_count=0;
	if(G_Motor_State.Aging_Test)
		if(G_Motor_State.Pos_Down_Arrive_Flag || G_Motor_State.Pos_Up_Arrive_Flag)
		{
			test_count++;
			if(test_count>15000)
			{
				G_Motor_State.Pos_Down_Arrive_Flag=0;
				G_Motor_State.Pos_Up_Arrive_Flag=0;
				G_Motor_State.DIR^=1;
				BRAKE_ON;
				G_Motor_State.RUN_STATE_1_FLAG = 1;
				G_Motor_State.Number_switches++;
				
				test_count=0;
			}
			
		}
}
