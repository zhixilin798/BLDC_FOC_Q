#include "uart.h"
#include "IR.h"
#include "Delay.h"
#include "com_motor.h"

#define SCREEN_ADDR 0x01

#define MAP_SIZE (sizeof(Screen_Map)/sizeof(Screen_Map_t))
#define STATE_MAP_SIZE (sizeof(Screen_State_Map)/sizeof(Screen_State_Map_t))
	
typedef struct{
	uint16_t addr;
	uint16_t *param;
} Screen_Map_t;

typedef struct{
	uint16_t addr;
	uint8_t *param;
} Screen_State_Map_t;

typedef struct{
	uint16_t motor1_up;
	uint16_t motor1_stop;
	uint16_t motor1_down;
	uint16_t motor2_up;
	uint16_t motor2_stop;
	uint16_t motor2_down;
	uint16_t motor2_set_data;
	uint16_t motor2_limit_clear;
	uint16_t motor1_up_rpm;
	uint16_t motor1_down_rpm;
	uint16_t motor1_up_degree;
	uint16_t window_limit_enter_exit;
	uint16_t window_up_limit_set;
	uint16_t window_down_limit_set;
	uint16_t window_up_limit_delete;
	uint16_t window_down_limit_delete;
	uint16_t addr_password_clear;
	uint16_t addr_password_set;
	uint16_t up_current_limit_set;
	uint16_t up_current_sensitivity_set;
	/*标志位*/
	uint8_t motor_pos_flag;//电机行程
	uint8_t software_date_flag;//软件日期
	uint8_t hardware_type;//硬件类型
	uint8_t product_formula;//产品配方
	uint8_t state1;
	uint8_t state2;
	uint8_t up_speed;
	uint8_t down_speed;
	uint8_t limit_state;
	uint8_t down_current_limit;
	uint8_t up_current_limit;
	uint8_t down_current_sensitivity;
	uint8_t up_current_sensitivity;
}	Screen_Param_t;

void UART_Receive_Con(void);
void Screen_Motor2_DIR_Write(uint8_t dir);
extern Screen_Param_t Scren_Para;
extern Screen_Map_t Screen_Map[];
extern Screen_State_Map_t Screen_State_Map[];
extern uint8_t Screen_Con_Flag;

