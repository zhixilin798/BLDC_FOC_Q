#include "touch_screen.h"

uint8_t Screen_Con_Flag=0,Screen_Send_Flag=0;
Screen_Param_t Scren_Para;
uint8_t motor2_limit_state=0,motor2_set_state=0,motor2_up_state=0,motor2_down_state=0;
uint8_t Motor_DIR=0;
Screen_Map_t Screen_Map[]={
{0xF002,(uint16_t *)&Scren_Para.motor1_up},
{0xF003,(uint16_t *)&Scren_Para.motor1_stop},
{0xF001,(uint16_t *)&Scren_Para.motor1_down},
{0xC040,(uint16_t *)&Scren_Para.motor1_up_rpm},//上升转速
{0xC030,(uint16_t *)&Scren_Para.motor1_down_rpm},//下降转速
{0xF801,(uint16_t *)&Scren_Para.motor1_up_degree},//开窗程度
{0xFFF0,(uint16_t *)&Scren_Para.window_limit_enter_exit},//进入(0x5A)/退出(0x01)行程设置界面
{0xFA31,(uint16_t *)&Scren_Para.window_up_limit_set},//上行程确认
{0xFA32,(uint16_t *)&Scren_Para.window_down_limit_set},//下行程确认
{0xFA35,(uint16_t *)&Scren_Para.motor2_limit_clear},//2为清上行程，1为清下行程
//10
{0xF101,(uint16_t *)&Scren_Para.motor2_up},
{0xF103,(uint16_t *)&Scren_Para.motor2_stop},
{0xF102,(uint16_t *)&Scren_Para.motor2_down},
{0xFA40,(uint16_t *)&Scren_Para.motor2_set_data},
//14
{0xFA02,(uint16_t *)&Scren_Para.addr_password_clear},//清码
{0xFA01,(uint16_t *)&Scren_Para.addr_password_set},//对码
{0xFC02,(uint16_t *)&Scren_Para.up_current_limit_set},//开窗电流
{0xFC04,(uint16_t *)&Scren_Para.up_current_sensitivity_set},//开窗灵敏度
};

Screen_State_Map_t Screen_State_Map[]={
	{0xFD10,(uint8_t *)&Scren_Para.motor_pos_flag},//行程
	{0x1007,(uint8_t *)&Scren_Para.software_date_flag},//软件日期
	{0x103A,(uint8_t *)&Scren_Para.hardware_type},//硬件型号
	{0x103D,(uint8_t *)&Scren_Para.product_formula},//产品配方
	{0xFF01,(uint8_t *)&Scren_Para.state1},//系统状态1
	{0xFF02,(uint8_t *)&Scren_Para.state2},//系统状态2
	{0xC040,(uint8_t *)&Scren_Para.up_speed},//上升速度
	{0xC030,(uint8_t *)&Scren_Para.down_speed},//下降速度
	{0xD160,(uint8_t *)&Scren_Para.limit_state},//限位状态
	{0xFC01,(uint8_t *)&Scren_Para.down_current_limit},//关窗电流
	{0xFC02,(uint8_t *)&Scren_Para.up_current_limit},//开窗电流
	{0xFC03,(uint8_t *)&Scren_Para.down_current_sensitivity},//关窗电流
	{0xFC04,(uint8_t *)&Scren_Para.up_current_sensitivity},//开窗电流
};
	
void Screen_Con(void)
{
	if(Screen_Con_Flag)
	{
		if(*Screen_Map[0].param)//模拟FR启动
		{
			IR_FLAG = 1;
			IR_Addr = 0x21;
			IR_Com = KEY1_DOWN;
			*Screen_Map[0].param=0;
		}
		else if(*Screen_Map[1].param)//模拟FR停止
		{
			IR_FLAG = 1;
			IR_Addr = 0x21;
			IR_Com = KEY2_DOWN;
			*Screen_Map[1].param=0;
		}
		else if(*Screen_Map[2].param)//模拟IR启动
		{
			
			IR_FLAG = 1;
			IR_Addr = 0x21;
			IR_Com = KEY3_DOWN;
			*Screen_Map[2].param=0;
		}
		else if(*Screen_Map[3].param)//up速度
		{
			if(*Screen_Map[3].param>=500 && *Screen_Map[3].param<=2000)
				G_MotorParam.up_speed_set = *Screen_Map[3].param * 2;
			*Screen_Map[3].param=0;
		}
		else if(*Screen_Map[4].param)//down速度
		{
			if(*Screen_Map[4].param>=500 && *Screen_Map[4].param<=2000)
				G_MotorParam.down_speed_set = *Screen_Map[4].param * 2;
			*Screen_Map[4].param=0;
		}
		else if(*Screen_Map[5].param)//开窗程度
		{
			G_MotorPid.Pos_Up_Set_Setter = G_MotorPid.Pos_Down_Setter + (Scren_Para.motor1_up_degree*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter))/100;
			*Screen_Map[5].param=0;
		}
		else if(*Screen_Map[6].param)//进入/退出窗电机/纱电机行程设置界面
		{
			if(*Screen_Map[6].param == 0x5A)//进入
			{
				G_Motor_State.Limit_Set_Flag = 1;
				motor2_set_state=0,motor2_limit_state=0;
				Buzzer_Flag = 1,Buzzer_Run_Count=3;
			}
			else if(*Screen_Map[6].param ==0x01)
			{
				if(motor2_set_state )//进入纱电机设置界面后如果有操作
					Screen_Motor2_normal_run(),motor2_set_state=0;
				G_Motor_State.Limit_Set_Flag = 0;
			}
			*Screen_Map[6].param=0;
		}
		else if(*Screen_Map[7].param)//上限位确认
		{
			IR_FLAG = 1;
			IR_Addr = 0x32;
			IR_Com = KEY1_DOWN;
			*Screen_Map[7].param=0;
		}
		else if(*Screen_Map[8].param)//下限位确认
		{
			IR_FLAG = 1;
			IR_Addr = 0x32;
			IR_Com = KEY3_DOWN;
			*Screen_Map[8].param=0;
		}
		else if(*Screen_Map[9].param)//行程删除
		{
			if(G_Motor_State.polarity)
			{
				if(*Screen_Map[9].param==1)
					G_MotorPid.Pos_Up_Setter_Flag = 0,G_Motor_State.Limit_Set_Flag = 1;
				else
					G_MotorPid.Pos_Down_Setter_Flag = 0,G_Motor_State.Limit_Set_Flag=1;
			}
			else
			{
				if(*Screen_Map[9].param==1)
					G_MotorPid.Pos_Down_Setter_Flag = 0,G_Motor_State.Limit_Set_Flag = 1;
				else
					G_MotorPid.Pos_Up_Setter_Flag = 0,G_Motor_State.Limit_Set_Flag=1;
			}
			*Screen_Map[9].param=0;
		}
		else if(*Screen_Map[10].param)//纱电机上升
		{
			Screen_Motor2_Up();
			*Screen_Map[10].param=0;
		}
		else if(*Screen_Map[11].param)//纱电机上升
		{
			Screen_Motor2_Stop();
			*Screen_Map[11].param=0;
		}
		else if(*Screen_Map[12].param)//纱电机上升
		{
			Screen_Motor2_Down();
			*Screen_Map[12].param=0;
		}
		else if(*Screen_Map[13].param)//纱电机设置界面下数据
		{
			switch(*Screen_Map[13].param){
				case 0x01:
					motor2_set_state = 1;
					if(motor2_limit_state==0)
						Screen_Motor2_inching_run(),motor2_limit_state++;
					else
						Screen_Motor2_Up();
					break;
				case 0x02:
					motor2_set_state = 1;
					if(motor2_limit_state==0)
						Screen_Motor2_inching_run(),motor2_limit_state++;
					else
						Screen_Motor2_Down();
					break;
				case 0x11://上限位
					motor2_set_state = 1;
					Screen_Motor2_Limit_1_Set();
					motor2_limit_state=0;
					break;
				case 0x12://下限位
					motor2_set_state = 1;
					Screen_Motor2_Limit_2_Set();
					motor2_limit_state=0;
					break;
				case 0x20://切换方向
					if(Motor_DIR)
						Screen_Motor2_DIR_Write(1),Motor_DIR=0;
					else
						Screen_Motor2_DIR_Write(0),Motor_DIR=1;
					break;
				case 0xCC://清除行程
					motor2_set_state = 1;
					Screen_Motor2_Reset();
					motor2_limit_state = 0;

			
					break;
			}
			*Screen_Map[12].param=0;
		}
		else if(*Screen_Map[14].param)//清码
		{
			switch(*Screen_Map[14].param){
				case 0x01://清全部
					break;
				case 0x02://清遥控器
					eq1_check[0]=0,eq1_check[1]=0,eq1_check[2]=0;
					Buzzer_Run_Count=2,Buzzer_Flag =1;
					break;
				case 0x03:
					break;
				case 0x04:
				break;
			}
			*Screen_Map[14].param=0;
		}
		else if(*Screen_Map[15].param)//清码
		{
			G_Motor_State.SET_MODEL = 1;
			IR_PASSWORD_FLAG = 1;//对码标志位
			REMOTE_FLAG=1;
			Buzzer_Flag = 1,Buzzer_Run_Count=3;
			*Screen_Map[15].param=0;
		}
		else if(*Screen_Map[16].param)//电流限制
		{
			if(*Screen_Map[16].param>=80 && *Screen_Map[16].param<=100)
				G_Motor_State.Up_Current_Limit = *Screen_Map[16].param;
			*Screen_Map[16].param=0;
		}
		else if(*Screen_Map[17].param)//灵敏度
		{
			if(*Screen_Map[17].param>=50 && *Screen_Map[17].param<=100)
				G_Motor_State.Up_Current_Sensitivity = *Screen_Map[17].param;
			*Screen_Map[17].param=0;
		}
		Screen_Con_Flag=0;
	}
}
void Screen_recive_u16(void)
{
	uint16_t addr,data;
	addr = RX_data[2]<<8;
	addr |= RX_data[3];
	data = RX_data[7]<<8;
	data |= RX_data[8];
	for(uint16_t i=0;i<MAP_SIZE;i++)
	{
		if(addr == Screen_Map[i].addr)
		{
			*Screen_Map[i].param = data;
			Screen_Con_Flag=1;
		}
			
	}
	Screen_Con();
}

void Screen_Send_Data(void)
{
	uint16_t data1=0;
	int32_t data2=0;
	if(Screen_Send_Flag)
	{
		TX_data[0] = SCREEN_ADDR;//地址
		TX_data[2] = RX_data[2];//地址H
		TX_data[3] = RX_data[3];//地址L
		TX_data[4] = 0;

		if(*Screen_State_Map[0].param)//行程
		{
			TX_data[1] = 0xA2;//数据类型
			data1 = (100*(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Back))/(G_MotorPid.Pos_Up_Setter - G_MotorPid.Pos_Down_Setter);
			TX_data[5] = 0;
			TX_data[6] = 0;
			TX_data[7] = 0;//data_H
			TX_data[8] = data1;//data_L
			*Screen_State_Map[0].param = 0;
		}
		else if(*Screen_State_Map[1].param)//软件日期
		{
			TX_data[1] = 0xA4;//数据类型
			data2 = 0x1350253;
			TX_data[5] = data2>>24;
			TX_data[6] = data2>>16;
			TX_data[7] = data2>>8;//data_H
			TX_data[8] = data2;//data_L
			*Screen_State_Map[1].param = 0;
		}
		else if(*Screen_State_Map[2].param)//硬件型号
		{
			TX_data[1] = 0xA4;//数据类型
			TX_data[5] = 'E';
			TX_data[6] = 'M';
			TX_data[7] = '0';//data_H
			TX_data[8] = '1';//data_L
			*Screen_State_Map[2].param = 0;
		}
		else if(*Screen_State_Map[3].param)//产品配方
		{

			TX_data[5] = 'S';
			TX_data[6] = 'D';
			TX_data[7] = 'Z';//data_H
			TX_data[8] = '1';//data_L
			*Screen_State_Map[3].param = 0;
		}
		else if(*Screen_State_Map[4].param)//系统状态1
		{
			TX_data[1] = 0xA2;//数据类型
			TX_data[7] = Sys_State_1>>8;//data_H
			TX_data[8] = Sys_State_1;//data_L

			*Screen_State_Map[4].param = 0;
		}
		else if(*Screen_State_Map[5].param)//系统状态2
		{
			TX_data[1] = 0xA2;//数据类型
			TX_data[7] = Sys_State_2>>8;//data_H
			TX_data[8] = Sys_State_2;//data_L

			*Screen_State_Map[5].param = 0;
		}
		else if(*Screen_State_Map[6].param)//上升速度
		{
			TX_data[1] = 0xA2;//数据类型u16
			TX_data[7] = G_MotorParam.up_speed_set>>9;
			TX_data[8] = G_MotorParam.up_speed_set>>1;
			*Screen_State_Map[6].param = 0;
		}
		else if(*Screen_State_Map[7].param)//下降速度
		{
			TX_data[1] = 0xA2;//数据类型u16
			TX_data[7] = G_MotorParam.down_speed_set>>9;
			TX_data[8] = G_MotorParam.down_speed_set>>1;
			*Screen_State_Map[7].param = 0;
		}
		else if(*Screen_State_Map[8].param)//行程状态
		{
			TX_data[1] = 0xA2;//数据类型u16
			TX_data[7] = 0;
			if(G_Motor_State.polarity)
			{
				if(G_MotorPid.Pos_Down_Setter_Flag)
					data1 |= 0x0010;
				else
					data1 &= ~0x0010;
				if(G_MotorPid.Pos_Up_Setter_Flag)
					data1 |= 0x0001;
				else
					data1 &= ~0x0001;
			}
			else
			{
				if(G_MotorPid.Pos_Up_Setter_Flag)
					data1 |= 0x0010;
				else
					data1 &= ~0x0010;
				if(G_MotorPid.Pos_Down_Setter_Flag)
					data1 |= 0x0001;
				else
					data1 &= ~0x0001;
				
			}
			TX_data[8] = data1;
			*Screen_State_Map[8].param = 0;
		}
		else if(*Screen_State_Map[9].param)
		{
			TX_data[1] = 0xA2;//数据类型u16
			TX_data[7] = 0;
			TX_data[8] = G_Motor_State.Down_Current_Limit;
			*Screen_State_Map[9].param = 0;
		}
		else if(*Screen_State_Map[10].param)
		{
			TX_data[1] = 0xA2;//数据类型u16
			TX_data[7] = 0;
			TX_data[8] = G_Motor_State.Up_Current_Limit;
			*Screen_State_Map[10].param = 0;
		}
		else if(*Screen_State_Map[11].param)
		{
			TX_data[1] = 0xA2;//数据类型u16
			TX_data[7] = 0;
			TX_data[8] = G_Motor_State.Down_Current_Sensitivity;
			*Screen_State_Map[11].param = 0;
		}
		else if(*Screen_State_Map[12].param)
		{
			TX_data[1] = 0xA2;//数据类型u16
			TX_data[7] = 0;
			TX_data[8] = G_Motor_State.Up_Current_Sensitivity;
			*Screen_State_Map[12].param = 0;
		}
		TX_data[9] = (TX_data[0]+TX_data[1]+TX_data[2]+TX_data[3]+TX_data[4]+TX_data[5]+TX_data[6]+TX_data[7]+TX_data[8]);
		TX_EN;
		UART_Send_String((char *)&TX_data,10);
		my_delay_1ms();
		RX_EN;
		Screen_Send_Flag = 0;
	}
	
}

void Screen_send_u16(void)
{
	/*
					0			 1		   2  		 3 		  4   		|5 6 7 8|    9
			地址 		CMD		ADDR_H	ADDR_L	ERR清除		|数据区|		校验
	*/
	uint16_t addr;
	addr = RX_data[2]<<8;
	addr |= RX_data[3];
	for(uint16_t i=0;i<STATE_MAP_SIZE;i++)
	{
		if(addr == Screen_State_Map[i].addr)
		{
			 *Screen_State_Map[i].param = 1;
			Screen_Send_Flag = 1;
		}
	}
		Screen_Send_Data();
}

void UART_Receive_Con(void)
{
	if(RX_Flag==1 && RX_ms>=8)
	{
		if(RX_data[0] == SCREEN_ADDR)
		{
			switch(RX_data[1]){
				case 0xA0:
					Screen_send_u16();
					break;
				case 0x51:
					
					break;
				case 0x52:
					Screen_recive_u16();
					break;
				case 0x54:
					
					break;
				default:
					break;
			}
		}
		else if(RX_data[0] == 0x55)
		{
			
		}
			
//			GPIOB->ODR ^= GPIO_Pin_0;
			RX_Flag = 0;
			p_data = 0;
		}
}

