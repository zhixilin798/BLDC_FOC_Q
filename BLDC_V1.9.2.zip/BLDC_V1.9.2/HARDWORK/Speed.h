#ifndef __SPEED_H
#define __SPEED_H

#include "stm32f10x.h" 
#include "tim_hall.h"
#include "Function.h"

void Speed_Loop(void);
void Speed_Up(uint8_t *up_flag,uint8_t down_time);
uint8_t Speed_Down(uint8_t up_time);
#endif
