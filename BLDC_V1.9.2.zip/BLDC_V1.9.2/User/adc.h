#ifndef __ADC_H
#define __ADC_H

#include "stm32f10x.h" 

void AD_DMA_Init(void);

extern  uint16_t AD_Value[4];
#endif
