#ifndef __FLASH_H
#define __FLASH_H

#include "stm32f10x.h" 
#include "Function.h"
#include "IR.h"
extern uint16_t Store_Data[];

void Store_Init(void);
void Store_Save(void);
void Store_Clear(void);
void MyFLASH_ProgramWord(uint32_t Address, uint32_t Data);

#endif
