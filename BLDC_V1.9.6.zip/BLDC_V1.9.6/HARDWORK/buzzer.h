#ifndef __BUZZER_H
#define __BUZZER_H

#include "gpio.h"
#include "Function.h"
void Buzzer_ON(void);
void Buzzer_OFF(void);
void Buzzer_Running(uint8_t *buzzer_flag,uint8_t run_count);

extern uint8_t Buzzer_Flag,Buzzer_Run_Count;

#endif
