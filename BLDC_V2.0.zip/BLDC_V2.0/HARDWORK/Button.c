#include "Button.h"
uint8_t last_key_state[8]={1,1,1,1,1,1,1,1};

void delay_5ms(void)
{
    volatile uint32_t i;
    for (i = 0; i < 360000; i++) {
        __NOP();  // 空指令
    }
}


uint8_t key_get(void)
{
	uint8_t key_num;
	uint8_t key_state[8];
	key_state[0] = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11);
	key_state[1] = WIN_ON;
	key_state[2] = WIN_OFF;
	key_state[3] = WIN_STOP;
	key_state[4] = S_ON;
	key_state[5] = S_OFF;
	key_state[6] = S_STOP;
	key_state[7] = LED_CON;
	if(key_state[0]==0 && last_key_state[0]==1)
	{
//		delay_5ms();
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11) == 0)
			key_num=1;
	}
	else if(key_state[1]==0 && last_key_state[1]==1)
	{
//		delay_5ms();
		if(WIN_ON == 0)
			key_num=2;
	}
	else if(key_state[2]==0 && last_key_state[2]==1)
	{
//		delay_5ms();
		if(WIN_OFF == 0)
			key_num=3;
	}
	else if(key_state[3]==0 && last_key_state[3]==1)
	{
//		delay_5ms();
		if(WIN_STOP == 0)
			key_num=4;
	}
	else if(key_state[4]==0 && last_key_state[4]==1)
	{
//		delay_5ms();
		if(S_ON == 0)
			key_num=5;
	}
	else if(key_state[5]==0 && last_key_state[5]==1)
	{
//		delay_5ms();
		if(S_OFF == 0)
			key_num=6;
	}
	else if(key_state[6]==0 && last_key_state[6]==1)
	{
//		delay_5ms();
		if(S_STOP == 0)
			key_num=7;
	}
	else if(key_state[7]==0 && last_key_state[7]==1)
	{
//		delay_5ms();
		if(LED_CON == 0)
			key_num=8;
	}
	else
		key_num=0;
	
	last_key_state[0] = key_state[0];
	last_key_state[1] = key_state[1];
	last_key_state[2] = key_state[2];
	last_key_state[3] = key_state[3];
	last_key_state[4] = key_state[4];
	last_key_state[5] = key_state[5];
	last_key_state[6] = key_state[6];
	last_key_state[7] = key_state[7];
	return key_num;
}

void Key_Manage(uint8_t *key_num)
{
	if(*key_num )
	{
		switch(*key_num){
			case 1:
				G_Motor_State.SET_MODEL = 1;
				IR_PASSWORD_FLAG = 1;//对码标志位
				REMOTE_FLAG=1;
				Buzzer_Flag = 1,Buzzer_Run_Count=3;
				break;
			case 2://窗下降
				IR_FLAG = 1;
				IR_Addr = 0x21;
				IR_Com = KEY3_DOWN;
				break;
			case 3://窗上升
				IR_FLAG = 1;
				IR_Addr = 0x21;
				IR_Com = KEY1_DOWN;
				break;
			case 4://窗停
				IR_FLAG = 1;
				IR_Addr = 0x21;
				IR_Com = KEY2_DOWN;
				break;
			case 5://纱下降
				Screen_Motor1_Down(80);
				Screen_Motor2_Down();
				break;
			case 6://纱上升
				Screen_Motor1_Up(80);
				Screen_Motor2_Up();
				break;
			case 7://纱停
				Screen_Motor1_Stop();
				Screen_Motor2_Stop();
				break;
			case 8://开灯
				
				break;
		}
		*key_num = 0;
	}
}
