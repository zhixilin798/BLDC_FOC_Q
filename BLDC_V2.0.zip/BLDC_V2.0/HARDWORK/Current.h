#ifndef __CURRENT_H
#define __CURRENT_H

#include "stm32f10x.h" 
#include "adc.h"
#include "Function.h"


typedef struct {  
	int32_t  As;  		// Input: phase-a
	int32_t  Bs;			// Input: phase-b
	int32_t  Cs;			// Input: phase-c
	int32_t  Alpha;		// Output:  a-axis
	int32_t  Beta;		// Output:  b-axis
} CLARKE ,*p_CLARKE ;


typedef struct {  
	int32_t  Alpha;  		// Input:  a-axis
	int32_t  Beta;	 	// Input:  b-axis
	int32_t  Angle;		// Input:  angle (pu)
	int32_t  Ds;			// Output:  d-axis
	int32_t  Qs;			// Output:  q-axis
	int32_t  Sine;
	int32_t  Cosine;
} PARK , *p_PARK ;

uint8_t Current_offset_read(void);
void ADC_Sample(uint8_t adc_revise_flag);
void  PARK_Cale(p_PARK pV);
void  CLARKE_Cale(p_CLARKE  pV);
void CURRENT_LOOP(uint8_t motor_dir);

extern int32_t CUR_U,CUR_V,CUR_W;
extern CLARKE ClarkeI;
extern PARK ParkI;

#endif
