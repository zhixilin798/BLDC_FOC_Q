#ifndef __FUNCTION_H
#define __FUNCTION_H
 
#include "gpio.h"

#define OVERCUR_SET	G_Motor_State.Motor_Fault |= 0x01
#define OVERVOL_SET	G_Motor_State.Motor_Fault |= 0x02
#define STALL_SET		G_Motor_State.Motor_Fault |= 0x04


#define PWM_HalfPerMax   ((u16)1800)
#define   _IQ10(A)       (int32_t)((A)<<15)      //   32768
#define   _IQ(A)          _IQ15(A) 
#define   _IQmpy(A,B)    (int32_t)((A*B)>>15)  
#define   _IQ10mpy(A,B)   (int32_t)((A*B)>>10)  
#define   _IQdiv2(A)     (int32_t)((A)>>1)
#define   _IQmpy2(A)     (int32_t)(A<<1)
#define   _IQdiv(A,B)    (int32_t)((A<<15)/B)


#define SIN_RAD     0x0300
#define U0_90       0x0000 
#define U90_180     0x0100
#define U180_270    0x0200
#define U270_360    0x0300

#define PWM_FREQ 10000    // 默认10kHz PWM频率，需根据实际情况修改
#define PI 3.14159265358979f


typedef struct {
	uint16_t PLL_Angle;    
	int32_t PLL_Speed;
	int32_t Angle_Error;
	int32_t PLL_Anhgle_Integral;
	int32_t Integral_Limit;
	int32_t PLL_Kp;
	int32_t PLL_Ki;
} PLL_Param_t;

//#################################################################################
typedef struct {  
	int32_t  Alpha;  		// Output:  d-axis
	int32_t  Beta;		// Output:  q-axis
	int32_t  Angle;		// Input:  angle (pu)
	int32_t  Ds;			// Input:  d-axis
	int32_t  Qs;			// Input:  q-axis
	int32_t  Sine;		// Input: Sine
	int32_t  Cosine;		// Input: Cosine
} IPARK , *p_IPARK;

typedef struct 	{ 
	int32_t Ualpha; 			// Input:   alpha-axis
	int32_t  Ubeta;			// Input:   beta-axis
	int32_t  Ta;				// Output:  phase-a
	int32_t  Tb;				// Output:  phase-b
	int32_t  Tc;				// Output:  phase-c
	int32_t  tmp1;			// Variable: temp
	int32_t  tmp2;			// Variable: temp
	int32_t  tmp3;			// Variable: temp
	uint16_t VecSector;		// Space vector sector
} SVPWM , *p_SVPWM ;

typedef struct 	{ 
	int32_t  IQAngle; 			// Input:   alpha-axis
	int32_t  IQSin;			// Input:   beta-axis
	int32_t  IQCos;				// Output:  phase-a		 
} IQSin_Cos , *p_IQSin_Cos;

//#################################################################################


typedef struct{
	uint16_t Motor_Fault;
	uint8_t DIR;
	uint8_t Turn_Flag;
	uint8_t Hall_State;
	int32_t speedRpm;					/* 实际转速/Rpm*/
	int32_t Angle_speed;
	int32_t Turn_Number;
	uint32_t Number_switches;//提升窗开关次数
	int16_t  Ia_mA;       /* A 相电流 mA */
	int16_t  Ib_mA;       /* B 相电流 mA*/
	uint8_t RUN_STATE;		/* 电机运行状态：0-静止，1-强拉启动，2-闭环运行，3-主动制动*/
	uint8_t RUN_STATE_1_FLAG;
	uint8_t STOP_STATE_FLAG;
	uint8_t Speed_Up_Flag; /*电机加速标志位*/
	uint8_t Speed_Down_Flag;	/*电机减速标志位*/
	uint8_t SET_MODEL;			/*设置状态下标志位*/
	uint8_t Limit_Set_Flag;			/*是否设置了限位标志位*/
	uint8_t polarity;					/*反向极性*/
	uint8_t Pos_Up_Arrive_Flag;		//上限位到达标志位
	uint8_t Pos_Down_Arrive_Flag;	//下限位到达标志位
	uint8_t Down_Current_Limit;//关窗电流限制
	uint8_t Up_Current_Limit;//开窗电流限制；
	uint8_t Down_Current_Sensitivity;//关窗电流灵敏度
	uint8_t Up_Current_Sensitivity;//开窗电流灵敏度
	uint8_t Little_Open_Flag;//微通风模式标志位
	uint8_t Little_Open_Start;//微通风启动标志位
	uint8_t Aging_Test; //老化标志位
	uint8_t Screen_Linkage_Flag;//窗纱联动标志位
	uint8_t Screen_Linkage_Start;//窗纱联动启动标志位
} Motor_State_t;

typedef struct {
	uint16_t alignTime_ms;  	/* 定位时间            */
	uint16_t startDuty;    		/* 启动占空比 %        */
	uint16_t pullFreq_Hz; 	  /* 强拉起步电频率      */
	uint16_t overCurrent; 		/* 过流阈值            */
	uint16_t overCurrent_Count; 		/* 过流阈值            */
	uint16_t overvoltage;			/* 过压阈值            */
	uint16_t stallTimeout_ms; /* 堵转超时阈值        */
	uint16_t up_speed_set;
	uint16_t down_speed_set;
	uint8_t  polePairs;				/* 极对数			        */
	int32_t CurrU_offset;
	int32_t CurrV_offset;
	int32_t CurrW_offset;
	uint8_t overCurrent_flag;
	
} MotorParam_t;

 typedef struct {
	uint32_t KP_CUR;                   
	int32_t KI_CUR;                   
	int32_t KD_CUR;   
	int32_t KP_SPD;                   
	int32_t KI_SPD;
	int32_t KD_SPD;     
	uint32_t KP_POS;	 
	uint32_t PI_Max;               /* 积分上限                  */
	uint32_t PI_Min;               /* 积分下限                  */
	int32_t SPD_Max;               /* 输出上限                  */
	int32_t CUR_Max;               /* 输出上限                  */
	uint32_t UMin;               /* 输出下限                  */
	int32_t CUR_Give;
	int32_t Speed_Give;		//速度给定
	int32_t Speed_Add;		//
	int32_t Speed_Inte;			//速度积分值
  int32_t CUR_Inte;			//电流积分值
	int32_t Pos_Up_Setter;		//上限位
	int32_t Pos_Up_Set_Setter;//行程设定
	int32_t Pos_win;//开窗程度
	int32_t Pos_little_win;//微通风开窗程度
	int32_t Pos_Down_Setter;	//下限位
	int32_t	Pos_Back;			//位置反馈值
	uint16_t PWM_Duty;		//占空比给定
	uint16_t Up_overduty;	//开环占空比上限		
	uint16_t Down_overduty; //开环占空比下限
	int32_t SPD_Uq;
	int32_t SPD_Ud;
	int32_t CUR_Uq;
	int32_t CUR_Ud;
	uint8_t Pos_Up_Setter_Flag;		//上限位设置标志位
	uint8_t Pos_Down_Setter_Flag;	//下限位设置标志位
	
} MotorPid_t;


void IQSin_Cos_Cale(p_IQSin_Cos  pV);
void drag_run(uint32_t Uq,uint32_t Ud,uint8_t Motor_DIR);
void motor_svpwm(uint32_t Uq,uint32_t Ud,uint8_t Motor_DIR);
void Motor_Drag(uint32_t Uq,uint32_t Ud,uint8_t Motor_DIR);
void SYS_STATE_MONITOR(void);
int32_t my_LPF(int32_t value,int32_t last_value);
int32_t mySpeed_LPF(int32_t value,int32_t last_value);
uint8_t direction_turn_angle_compensation(uint8_t motor_dir);
int32_t my_abs(int32_t data);
int32_t my_fmax(int32_t value1,int32_t value2);
void MOTOR_RUN_Start(void);
void run_test(void);
void SpeedPll(void);

extern PLL_Param_t			PLL_Param;
extern Motor_State_t 		G_Motor_State;
extern MotorParam_t			G_MotorParam;
extern MotorPid_t				G_MotorPid;
extern IPARK        IparkU;
extern SVPWM        Svpwmdq;
extern IQSin_Cos    AngleSin_Cos;
extern uint16_t Motor_Start_msDelay,Motor_Stop_msDelay;
extern uint16_t Sys_State_1,Sys_State_2;
extern uint8_t ERROR_FLAG;
#endif
