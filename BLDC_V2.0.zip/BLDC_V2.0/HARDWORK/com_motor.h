#include "pwm.h"
#include "uart.h"
#include "delay.h"

extern char control_map[][10];
extern uint8_t M_RX_FLAG;

void Screen_Motor1_Up(uint8_t Duty);
void Screen_Motor1_Down(uint8_t Duty);
void Screen_Motor1_Stop(void);


void Screen_Motor2_Up(void);
void Screen_Motor2_Stop(void);
void Screen_Motor2_Down(void);
void Screen_Motor2_Limit_1_Set(void);//限位1设置
void Screen_Motor2_Limit_2_Set(void);//限位2设置
void Screen_Motor2_Reset(void);//重置
void Screen_Motor2_inching_run(void);//点动
void Screen_Motor2_normal_run(void);//长动

