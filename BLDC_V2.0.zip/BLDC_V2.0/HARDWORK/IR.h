#ifndef __IR_H
#define __IR_H

#include "gpio.h"
#include "tim_hall.h"
#include "buzzer.h"
#include "com_motor.h"

#define DEVICE_ADDR1 	0x8A
#define DEVICE_ADDR2 	0xA7
#define DEVICE_ADDR3 	0x03
#define DEVICE_ADDR4 	0x01 //���

#define KEY1_UP			0x1E
#define KEY1_DOWN		0x11
#define KEY2_UP			0x55
#define KEY2_DOWN		0x55
#define KEY3_UP			0x3C
#define KEY3_DOWN		0x33
#define KEY4_UP			0xCC
#define KEY4_DOWN		0xCC

#define KEY1_ADDR		0x21
#define KEY2_ADDR		0x21
#define KEY3_ADDR		0x21
#define KEY4_ADDR		0x03
#define KEY5_ADDR		0x03
#define KEY6_ADDR		0x03

void IR_Con(uint8_t *ir_flag);
extern uint8_t IR_Data[],IR_FLAG,IR_PASSWORD_FLAG,eq1_check[3],eq2_check[3],IR_Addr,IR_Com,REMOTE_FLAG,TURN_FLAG;
extern uint32_t Limit_Set_ms;
extern uint16_t SET_TIME,KEY1_TIME,KEY2_TIME;
#endif
