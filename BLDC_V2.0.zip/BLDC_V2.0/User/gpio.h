#ifndef __GPIO_H
#define __GPIO_H

#include "stm32f10x.h" 

void RCC_Configuration(void);
#define BRAKE_OFF GPIO_SetBits(GPIOA,GPIO_Pin_12)
#define BRAKE_ON GPIO_ResetBits(GPIOA,GPIO_Pin_12)

#define TOGGLE_SWITCH_1 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)
#define TOGGLE_SWITCH_2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)

void GPIO_OUT_Init(void);
void GPIO_IN_Init(void);
void IR_Init(void);
void Power_Failure_Detection_Init(void);
#endif
