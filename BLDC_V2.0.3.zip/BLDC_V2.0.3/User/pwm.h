#ifndef __PWM_H
#define __PWM_H

#include "stm32f10x.h" 
#include "adc.h"
void TIM1_PWM_Init(void);
void TIM3_PWM_Init(void);
void PWM_ENABLE(void);
void PWM_DISABLE(void);
#endif
