#ifndef __TIM_HALL_H
#define __TIM_HALL_H

#include "stm32f10x.h" 
#include "Function.h"
#include "flash.h"
#include "Position.h"
void HALL_Init(void);
void TIM4_Init(void);
void TIM3_Init(void);
void Motor_Step(uint8_t hall_state,uint8_t run_dir);

extern uint8_t HALL_STATE,HALL_FLAG,HALL_STEP[7];
extern uint32_t HALL_TIM;
extern uint32_t hall_time;
extern uint8_t LAST_UP_HALL_STATE_MAP[7],LAST_HALL_STATE;
extern uint16_t Angledown_revise[8],Angleup_revise[8];
#endif
