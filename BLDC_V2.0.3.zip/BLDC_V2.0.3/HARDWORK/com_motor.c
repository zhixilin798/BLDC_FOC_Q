#include "com_motor.h"

uint8_t M_RX_FLAG=0;
char control_map[][10] = {
	{0x55,0xFE,0xFE,0x03,0x01,0xB9,0x24},//上行
	{0x55,0xFE,0xFE,0x03,0x02,0xF9,0x25},//下行
	{0x55,0xFE,0xFE,0x03,0x03,0x38,0xE5},//停
	{0x55,0xFE,0xFE,0x02,0x0A,0x02,0x00,0x00,0x54,0xC1},//长动模式
	{0x55,0xFE,0xFE,0x02,0x0A,0x02,0x01,0x00,0x55,0x51},//点动模式
	{0x55,0xFE,0xFE,0x03,0x05,0x01,0x26,0xB2},//行程1设置
	{0x55,0xFE,0xFE,0x03,0x05,0x02,0x66,0xB3},//行程2设置
	{0x55,0xFE,0xFE,0x03,0x08,0x79,0x22},//恢复出厂设置
	{0x55,0xFE,0xFE,0x01,0x03,0x01,0x84,0xd2},//读方向---rx[5]
	{0x55,0xFE,0xFE,0x02,0x03,0x01,0x01,0x13,0xE7},//写方向1
	{0x55,0xFE,0xFE,0x02,0x03,0x01,0x00,0xD2,0x27},//写方向0
};

/*485通信电机*/
void Screen_Motor2_Up(void)
{
	TX_EN;
	Serial_Init(9600);
	UART_Send_String(control_map[0],7);
	my_delay_1ms();
	Serial_Init(115200);
	RX_EN;
}
void Screen_Motor2_Stop(void)
{
	TX_EN;
	Serial_Init(9600);
	UART_Send_String(control_map[2],7);
	my_delay_1ms();
	Serial_Init(115200);
	RX_EN;
}
void Screen_Motor2_Down(void)
{
	TX_EN;
	Serial_Init(9600);
	UART_Send_String(control_map[1],7);
	my_delay_1ms();
	Serial_Init(115200);
	RX_EN;
}

void Screen_Motor2_Limit_1_Set(void)//限位1设置
{
	TX_EN;
	Serial_Init(9600);
	UART_Send_String(control_map[5],8);
	my_delay_1ms();
	Serial_Init(115200);
	RX_EN;
}
void Screen_Motor2_Limit_2_Set(void)//限位2设置
{
	TX_EN;
	Serial_Init(9600);
	UART_Send_String(control_map[6],8);
	my_delay_1ms();
	Serial_Init(115200);
	RX_EN;
}

void Screen_Motor2_Reset(void)//重置
{
	TX_EN;
	Serial_Init(9600);
	UART_Send_String(control_map[7],7);
	my_delay_1ms();
	Serial_Init(115200);
	RX_EN;
}

void Screen_Motor2_inching_run(void)//点动
{
	TX_EN;
	Serial_Init(9600);
	UART_Send_String(control_map[4],10);
	my_delay_1ms();
	Serial_Init(115200);
	RX_EN;
}

void Screen_Motor2_normal_run(void)//长动
{
	TX_EN;
	Serial_Init(9600);
	UART_Send_String(control_map[3],10);
	my_delay_1ms();
	Serial_Init(115200);
	RX_EN;
}
void Screen_Motor2_DIR_Write(uint8_t dir)
{
	if(dir)
	{
		TX_EN;
		Serial_Init(9600);
		UART_Send_String(control_map[9],9);
		my_delay_1ms();
		Serial_Init(115200);
		RX_EN;
	}
	else
	{
		TX_EN;
		Serial_Init(9600);
		UART_Send_String(control_map[10],9);
		my_delay_1ms();
		Serial_Init(115200);
		RX_EN;
	}
		
}

/*机械限位电机*/
void Screen_Motor1_Up(uint8_t Duty)
{
	TIM3->CCR1 = 85;
	GPIO_ResetBits(GPIOA,GPIO_Pin_5);
	GPIO_ResetBits(GPIOB,GPIO_Pin_11);
	TIM3->CCR2 = 100;
	
}

void Screen_Motor1_Down(uint8_t Duty)
{
	TIM3->CCR1 = 0;
	GPIO_SetBits(GPIOA,GPIO_Pin_5);
	GPIO_SetBits(GPIOB,GPIO_Pin_11);
	TIM3->CCR2 = 100-85;
	
}


void Screen_Motor1_Stop(void)
{
	TIM3->CCR1 = 0;
	GPIO_ResetBits(GPIOA,GPIO_Pin_5);
	GPIO_ResetBits(GPIOB,GPIO_Pin_11);
	TIM3->CCR2 = 0;
}
