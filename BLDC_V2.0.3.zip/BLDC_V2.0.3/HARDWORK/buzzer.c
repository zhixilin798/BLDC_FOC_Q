#include "buzzer.h"

uint8_t Buzzer_Flag=0,Buzzer_Run_Count=0;
volatile uint32_t count=0,count_1=0;
volatile uint8_t real_run_count=0;
void Buzzer_ON(void)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_2,Bit_SET);
}

void Buzzer_OFF(void)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_2,Bit_RESET);
}

void Buzzer_Running(uint8_t *buzzer_flag,uint8_t run_count)
{
	
	if(*buzzer_flag)
	{
		count++;
		if(count>0 && count<10000)
			Buzzer_ON();
		else 
			Buzzer_OFF();
		if(count>20000)
			real_run_count++,count=0;
		//次数判定
		if(real_run_count >= run_count)
			real_run_count=0,*buzzer_flag=0;
	}
	if((G_MotorPid.Pos_Up_Setter_Flag==0 || G_MotorPid.Pos_Down_Setter_Flag==0) && *buzzer_flag==0 && G_Motor_State.Limit_Set_Flag==0)//未设置限位报警
	{
		if(G_Motor_State.RUN_STATE)
		{
				count_1++;
			if(count_1>0 && count_1<100000)
				Buzzer_OFF();
			else 
				Buzzer_ON();
			if(count_1>150000)
				count_1=0;
		}
		else
			Buzzer_OFF(),count=0;
	}
}
