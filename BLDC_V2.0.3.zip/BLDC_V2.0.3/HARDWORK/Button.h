#ifndef __BUTTON_H
#define __BUTTON_H

#include "gpio.h"
#include "Function.h"
#include "IR.h"
#include "Buzzer.h"
#include "IR.h"

/*�ɽӵ�*/
#define WIN_ON		GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_14)
#define WIN_OFF		GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_15)
#define WIN_STOP	GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13)
#define S_ON			GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)
#define S_OFF			GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)
#define S_STOP		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)
#define LED_CON		GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)

uint8_t key_get(void);
void Key_Manage(uint8_t *key_num);
#endif
