#include "Current.h"

CLARKE       ClarkeI;
PARK         ParkI;
int32_t CUR_U,CUR_V,CUR_W;
void Delay_10ms(void)
{
    volatile uint32_t i;
    
    // 循环次数约180000，可根据实际测试微调
    for(i = 0; i < 180000; i++)
    {
        __NOP();  // 空操作指令，防止循环被优化掉
    }
}


void  PARK_Cale(p_PARK pV)
{
	pV->Ds = _IQmpy(pV->Alpha,pV->Cosine) + _IQmpy(pV->Beta,pV->Sine);
  pV->Qs = _IQmpy(pV->Beta,pV->Cosine) - _IQmpy(pV->Alpha,pV->Sine);
}

void  CLARKE_Cale(p_CLARKE  pV)
{
	pV->Alpha = pV->As;
	pV->Beta = _IQmpy((pV->As +_IQmpy2(pV->Bs)),18918);  //  _IQ(0.57735026918963)
}

uint8_t Current_offset_read(void)
{
	for(uint8_t i=0;i<16;i++)
	{
		G_MotorParam.CurrU_offset+=AD_Value[0];
		G_MotorParam.CurrV_offset+=AD_Value[1];
		G_MotorParam.CurrW_offset+=AD_Value[2];
		Delay_10ms();
		Delay_10ms();
	}
	G_MotorParam.CurrU_offset = G_MotorParam.CurrU_offset>>4;
	G_MotorParam.CurrV_offset = G_MotorParam.CurrV_offset>>4;
	G_MotorParam.CurrW_offset = G_MotorParam.CurrW_offset>>4;
	
	if(G_MotorParam.CurrU_offset<1500 || G_MotorParam.CurrU_offset>2500)
		return 1;
	 if(G_MotorParam.CurrV_offset<1500 || G_MotorParam.CurrV_offset>2500)
		return 2;
	else if(G_MotorParam.CurrW_offset<1500 || G_MotorParam.CurrW_offset>2500)
		return 3;
	else
		return 0;
}

void ADC_Sample(uint8_t adc_revise_flag)
{
	if(adc_revise_flag==0)
	{
		AD_Value[0] = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
		AD_Value[1] = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
		AD_Value[2] = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_3);
		
		CUR_U = AD_Value[0] - G_MotorParam.CurrU_offset;
		CUR_V = AD_Value[1] - G_MotorParam.CurrV_offset;
		CUR_W = AD_Value[2] - G_MotorParam.CurrW_offset;
	}
	else
	{
		AD_Value[0] = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
		AD_Value[1] = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
		AD_Value[2] = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_3);
	}
	
}
	int32_t CUR_error;
void CURRENT_LOOP(uint8_t motor_dir)
{
	G_MotorPid.CUR_Max = 15120000; //8000*2^8;

	if(motor_dir)
		CUR_error = G_MotorPid.CUR_Give - ParkI.Qs;
	else
		CUR_error = G_MotorPid.CUR_Give + ParkI.Qs;

	G_MotorPid.CUR_Inte += (G_MotorPid.KI_CUR * CUR_error);//积分
	if(G_MotorPid.CUR_Inte > G_MotorPid.CUR_Max)
		G_MotorPid.CUR_Inte = G_MotorPid.CUR_Max;
	else if(G_MotorPid.CUR_Inte < 0)
		G_MotorPid.CUR_Inte = 0;
	
	if(CUR_error<0)
		CUR_error = 0;
	G_MotorPid.CUR_Uq = ((G_MotorPid.KP_CUR*CUR_error + G_MotorPid.CUR_Inte)>>8);
	if(G_MotorPid.CUR_Uq>20000)
		G_MotorPid.CUR_Uq = 20000;
}

